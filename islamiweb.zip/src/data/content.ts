export const LOGO_URL =
  "https://blogger.googleusercontent.com/img/a/AVvXsEiW2Sfw5ogSKhZbFiB-VdNXwmZoMGLTGPgx5ZYrTY8859clBvRGxgx-Dwc3i03YiUs1WiiL84uTSAlZ8civ17IWTI5Emt2vXmpT-yRTzf4620rY_4Ib_vmUEGFfLXjzMiCfmQoWUg1mmj5hQu1IpD1CYguF9GocJ81MhsQTuPgt79-I8uOaPyGT0Qzs00=s200";

export type Tool = {
  title: string;
  desc: string;
  icon: string;
  group: string;
};

export type Article = {
  title: string;
  excerpt: string;
  category: string;
  date: string;
  readTime: string;
};

export const TOOLS: Tool[] = [
  { title: "Arabic Pegon", desc: "Konversi aksara Latin ke Arab Pegon untuk literasi pesantren.", icon: "✍️", group: "Tulis" },
  { title: "Arabic Calligraphy Pro", desc: "Generator kaligrafi Arab berbasis vektor gaya CorelDRAW.", icon: "✒️", group: "Tulis" },
  { title: "Arabic Keyboard", desc: "Papan ketik Arab virtual untuk menulis teks langsung.", icon: "⌨️", group: "Tulis" },
  { title: "Kalender Hijriah", desc: "Penanggalan multi-konversi Masehi, Hijriah, dan Jawa.", icon: "📅", group: "Waktu" },
  { title: "Jadwal Sholat", desc: "Pengingat otomatis dan penunjuk waktu salat real-time.", icon: "⏱️", group: "Waktu" },
  { title: "Murottal 30 Juz", desc: "Pemutar audio Al-Qur'an digital interaktif 30 Juz.", icon: "🎧", group: "Qur'an" },
  { title: "Al-Qur'an Digital", desc: "Mushaf digital portable untuk membaca di mana saja.", icon: "📖", group: "Qur'an" },
  { title: "Kalkulator Zakat", desc: "Hitung zakat maal 2,5% secara cepat dan akurat.", icon: "💰", group: "Ibadah" },
  { title: "Wirid & Do'a", desc: "Kumpulan wirid dan doa harian pilihan.", icon: "📿", group: "Ibadah" },
  { title: "Hadist Bukhori", desc: "Kumpulan hadits shahih pilihan dari Bukhari.", icon: "📜", group: "Ibadah" },
  { title: "WebOffice Suite", desc: "Alat produktivitas perkantoran berbasis web terintegrasi.", icon: "💼", group: "Produktivitas" },
  { title: "Khazanah Kitab", desc: "Kajian teks dan terjemahan literatur klasik Islam.", icon: "📚", group: "Pustaka" },
];

export const CATEGORIES = ["Semua", "Nasional", "Hikmah", "Budaya", "Kesehatan", "Internasional"];

export const ARTICLES: Article[] = [
  {
    title: "Meneladani Akhlak Rasulullah dalam Kehidupan Modern",
    excerpt:
      "Akhlak mulia Rasulullah SAW tetap relevan di era digital. Bagaimana menerapkannya dalam interaksi sehari-hari?",
    category: "Hikmah",
    date: "12 Mei 2025",
    readTime: "6 menit",
  },
  {
    title: "Peran Pesantren dalam Melestarikan Aksara Pegon",
    excerpt:
      "Aksara Pegon menjadi jembatan literasi pesantren yang kaya makna. Upaya pelestariannya terus dilakukan.",
    category: "Budaya",
    date: "10 Mei 2025",
    readTime: "5 menit",
  },
  {
    title: "Panduan Lengkap Menghitung Zakat Maal",
    excerpt:
      "Zakat bukan sekadar kewajiban, tetapi sarana membersihkan harta. Simak panduan praktis perhitungannya.",
    category: "Nasional",
    date: "8 Mei 2025",
    readTime: "7 menit",
  },
  {
    title: "Menjaga Kesehatan Jiwa dengan Dzikir dan Ibadah",
    excerpt:
      "Ketenangan hati dapat diraih melalui dzikir. Ilmu kesehatan modern pun mengakuinya.",
    category: "Kesehatan",
    date: "6 Mei 2025",
    readTime: "4 menit",
  },
  {
    title: "Perkembangan Islam di Kawasan Asia Tenggara",
    excerpt:
      "Dinamika umat Islam di Asia Tenggara menunjukkan pertumbuhan yang signifikan dan beragam.",
    category: "Internasional",
    date: "4 Mei 2025",
    readTime: "8 menit",
  },
  {
    title: "Adab Menuntut Ilmu Menurut Para Ulama Klasik",
    excerpt:
      "Para ulama mewariskan adab mulia dalam menuntut ilmu. Ini yang perlu kita teladani hari ini.",
    category: "Hikmah",
    date: "2 Mei 2025",
    readTime: "6 menit",
  },
];

export const NAV_ITEMS = [
  "Nasional",
  "Hikmah",
  "Budaya",
  "Kesehatan",
  "Internasional",
  "Khutbah",
  "Pustaka",
  "Tokoh",
  "Ramadhan",
  "Seni",
];

export const POPULAR_POSTS = [
  "Preparing Your Body for Ramadan",
  "Health Tips for Hajj and Umrah Pilgrims",
  "Managing Stress with Prayer and Mindfulness",
  "Caring for Elderly Family Members",
  "The Lantern of the Old Mosque",
];

export const ARCHIVE = [
  ["2026-07", 9],
  ["2026-06", 30],
  ["2026-05", 31],
  ["2026-04", 30],
  ["2026-03", 31],
  ["2026-02", 28],
  ["2026-01", 31],
] as [string, number][];

export const LABELS = [
  "Warta",
  "Nasional",
  "Daerah",
  "Internasional",
  "Risalah",
  "Redaksi",
  "Obituari",
  "Tokoh",
  "Hikmah",
  "Kesehatan",
  "Cerpen",
  "Puisi",
  "Pidato",
  "Khutbah",
  "Seni",
  "Budaya",
  "Ramadhan",
  "Pustaka",
  "Humor",
];

export const OLDER_POSTS = [
  "How Islamic Media Covers Global Events Responsibly",
  "Press Ethics in Muslim Newsrooms Explained",
  "How to Verify News Before Sharing It: An Islamic Perspective",
  "The Rise of Digital Islamic Journalism",
  "Fighting Misinformation in Muslim Communities",
];

export const FOOTER_GROUPS: { title: string; items: string[] }[] = [
  {
    title: "Situs",
    items: ["Home", "About Us", "Contact Us", "Privacy", "License", "Terms & Conditions"],
  },
  {
    title: "Layanan",
    items: ["Choices", "Disclaimer", "Partner", "Editorial", "Advertise", "Join the Team"],
  },
  {
    title: "Program",
    items: ["News Update", "Academy", "E-Course", "Training", "Private", "Forum Komunitas"],
  },
  {
    title: "Peta & Feed",
    items: ["Sitemaps", "Sitemap XML", "RSS XML", "Atom XML"],
  },
];