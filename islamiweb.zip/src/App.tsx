import { useState } from "react";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { ToolGrid } from "@/components/ToolGrid";
import { ArticleList } from "@/components/ArticleList";
import { Sidebar } from "@/components/Sidebar";
import { Footer } from "@/components/Footer";
import { AdSlot } from "@/components/AdSlot";
import { ToolModal } from "@/components/ToolModal";
import { TOOLS, ARTICLES, CATEGORIES } from "@/data/content";

export default function App() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("Semua");
  const [activeTool, setActiveTool] = useState<string | null>(null);

  const filteredTools = TOOLS.filter(
    (t) =>
      t.title.toLowerCase().includes(query.toLowerCase()) ||
      t.desc.toLowerCase().includes(query.toLowerCase())
  );

  const filteredArticles = ARTICLES.filter(
    (a) => activeCategory === "Semua" || a.category === activeCategory
  );

  return (
    <div className="min-h-screen bg-emerald-50/40 text-slate-800">
      <Header query={query} onQueryChange={setQuery} />
      <Hero />

      <div className="mx-auto w-full max-w-6xl px-4 pt-8">
        <AdSlot variant="leaderboard" />
      </div>

      <main className="mx-auto grid w-full max-w-6xl grid-cols-1 gap-8 px-4 py-10 lg:grid-cols-3">
        <div className="space-y-10 lg:col-span-2">
          <ToolGrid tools={filteredTools} onOpen={setActiveTool} />
          <AdSlot variant="inline" />
          <ArticleList
            articles={filteredArticles}
            categories={CATEGORIES}
            activeCategory={activeCategory}
            onCategoryChange={setActiveCategory}
          />
        </div>
        <Sidebar />
      </main>

      <div className="mx-auto w-full max-w-6xl px-4 pb-10">
        <AdSlot variant="leaderboard" />
      </div>

      <Footer />

      <ToolModal tool={activeTool} onClose={() => setActiveTool(null)} />
    </div>
  );
}