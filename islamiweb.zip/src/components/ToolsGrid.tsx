import {
  PenTool,
  Feather,
  CalendarDays,
  Clock,
  Headphones,
  BookOpen,
  Briefcase,
  Library,
} from "lucide-react";

const tools = [
  { id: "arabic-pegon", icon: PenTool, label: "Arabic Pegon", tone: "bg-emerald-100 text-emerald-800" },
  { id: "calligraphy", icon: Feather, label: "Calligraphy Pro", tone: "bg-amber-100 text-amber-800" },
  { id: "kalender", icon: CalendarDays, label: "Kalender", tone: "bg-teal-100 text-teal-800" },
  { id: "jadwal-sholat", icon: Clock, label: "Jadwal Sholat", tone: "bg-emerald-100 text-emerald-800" },
  { id: "murotal", icon: Headphones, label: "Murotal 30 Juz", tone: "bg-amber-100 text-amber-800" },
  { id: "alquran", icon: BookOpen, label: "Al-Qur'an Digital", tone: "bg-teal-100 text-teal-800" },
  { id: "weboffice", icon: Briefcase, label: "WebOffice Suite", tone: "bg-emerald-100 text-emerald-800" },
  { id: "khazanah", icon: Library, label: "Khazanah Kitab", tone: "bg-amber-100 text-amber-800" },
];

type Props = {
  onOpen: (id: string) => void;
};

export function ToolsGrid({ onOpen }: Props) {
  return (
    <section>
      <div className="mb-3 flex items-end justify-between">
        <div>
          <h2 className="font-serif text-xl font-bold text-emerald-900">
            Tools Islami
          </h2>
          <p className="text-xs text-slate-500">Layanan digital terpadu</p>
        </div>
        <button
          onClick={() => onOpen("tools")}
          className="text-xs font-semibold text-emerald-700 hover:text-emerald-900"
        >
          Lihat semua
        </button>
      </div>

      <div className="grid grid-cols-4 gap-3">
        {tools.map(({ id, icon: Icon, label, tone }) => (
          <button
            key={id}
            onClick={() => onOpen(id)}
            className="group flex flex-col items-center gap-2 rounded-2xl border border-emerald-100/70 bg-white p-3 shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-200 hover:shadow-md active:scale-95"
          >
            <span
              className={`flex h-11 w-11 items-center justify-center rounded-xl ${tone}`}
            >
              <Icon className="h-5 w-5" />
            </span>
            <span className="text-center text-[10px] font-medium leading-tight text-slate-600">
              {label}
            </span>
          </button>
        ))}
      </div>
    </section>
  );
}