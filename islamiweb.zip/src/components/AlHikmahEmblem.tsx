type Props = {
  size?: number;
  className?: string;
};

export function AlHikmahEmblem({ size = 400, className = "" }: Props) {
  return (
    <svg
      viewBox="0 0 500 500"
      width={size}
      height={size}
      role="img"
      aria-label="Emblem ALHIKMAH - Al-Amal"
      className={className}
    >
      <rect width="500" height="500" fill="#ffffff" />

      <circle cx="250" cy="250" r="200" fill="#A87B1F" />
      <circle cx="256" cy="246" r="182" fill="#ffffff" />

      <circle cx="250" cy="250" r="168" fill="#1C4B4B" />

      <path
        d="M 352 118
           C 300 78, 214 74, 156 118
           C 108 154, 92 214, 110 262
           C 122 296, 150 322, 186 334
           C 150 314, 128 282, 124 244
           C 118 190, 152 138, 208 120
           C 262 102, 320 108, 352 118 Z"
        fill="#ffffff"
      />

      <path
        d="M 344 196 L 344 300 L 330 300 L 330 210 L 344 196 Z"
        fill="#ffffff"
      />
      <path d="M 330 232 L 316 232 L 316 246 L 330 246 Z" fill="#ffffff" />

      <text
        x="250"
        y="272"
        textAnchor="middle"
        fill="#ffffff"
        fontSize="118"
        fontWeight="700"
        fontFamily="'Amiri', 'Scheherazade New', 'Traditional Arabic', serif"
        direction="rtl"
      >
        الأمل
      </text>

      <circle cx="250" cy="240" r="7" fill="#ffffff" />
    </svg>
  );
}