import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { AdSlot } from "@/components/AdSlot";

type Props = {
  tool: string | null;
  onClose: () => void;
};

const PRAYER_TIMES: [string, string][] = [
  ["Subuh", "04:32"],
  ["Dzuhur", "11:48"],
  ["Ashar", "15:06"],
  ["Maghrib", "17:52"],
  ["Isya", "19:04"],
];

const WIRID = [
  "Subhanallah (33x)",
  "Alhamdulillah (33x)",
  "Allahu Akbar (33x)",
  "La ilaha illallah (100x)",
  "Astaghfirullah (100x)",
];

const HADITS = [
  "Sesungguhnya amal itu tergantung niatnya. (Bukhari)",
  "Sebaik-baik kalian adalah yang mempelajari Al-Qur'an dan mengajarkannya. (Bukhari)",
  "Barangsiapa menempuh jalan menuntut ilmu, Allah mudahkan jalannya ke surga. (Muslim)",
];

const SURAHS: [string, string][] = [
  ["1. Al-Fatihah", "7 ayat"],
  ["2. Al-Baqarah", "286 ayat"],
  ["18. Al-Kahf", "110 ayat"],
  ["36. Yasin", "83 ayat"],
  ["55. Ar-Rahman", "78 ayat"],
  ["112. Al-Ikhlas", "4 ayat"],
];

const ARABIC_KEYS = [
  "ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي","ء","أ","إ","آ","ة","ى","ؤ","ئ",
];

const PEGON_MAP: Record<string, string> = {
  a: "ا", b: "ب", t: "ت", j: "ج", d: "د", r: "ر", z: "ز", s: "س", f: "ف",
  q: "ق", k: "ك", l: "ل", m: "م", n: "ن", w: "و", h: "ه", y: "ي", g: "غ",
  c: "چ", p: "ڤ", v: "ۏ", o: "و", e: "ي", i: "ي", u: "و",
};

function toPegon(text: string) {
  return text
    .toLowerCase()
    .split("")
    .map((ch) => PEGON_MAP[ch] ?? ch)
    .join("");
}

const HANDLED = [
  "Jadwal Sholat",
  "Kalkulator Zakat",
  "Arabic Pegon",
  "Arabic Keyboard",
  "Wirid & Do'a",
  "Hadist Bukhori",
  "Al-Qur'an Digital",
  "Murottal 30 Juz",
  "Kalender Hijriah",
  "Arabic Calligraphy Pro",
  "WebOffice Suite",
  "Khazanah Kitab",
];

export function ToolModal({ tool, onClose }: Props) {
  const [now, setNow] = useState(new Date());
  const [zakat, setZakat] = useState("");
  const [pegon, setPegon] = useState("");
  const [arabic, setArabic] = useState("");
  const [surah, setSurah] = useState<string | null>(null);
  const [playing, setPlaying] = useState(false);
  const [juz, setJuz] = useState(1);
  const [calli, setCalli] = useState("الأمل");
  const [note, setNote] = useState("");
  const [kitab, setKitab] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    if (!tool) return;
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, [tool]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  useEffect(() => {
    if (tool !== "Arabic Calligraphy Pro" || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#1C4B4B";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 64px serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(calli || "الأمل", canvas.width / 2, canvas.height / 2);
  }, [calli, tool]);

  const zakatValue = useMemo(() => {
    const n = parseFloat(zakat.replace(/[^\d.]/g, ""));
    if (!n || Number.isNaN(n)) return null;
    return (n * 0.025).toLocaleString("id-ID", { maximumFractionDigits: 0 });
  }, [zakat]);

  const hijri = useMemo(() => {
    try {
      return new Intl.DateTimeFormat("id-ID-u-ca-islamic", {
        day: "numeric",
        month: "long",
        year: "numeric",
      }).format(now);
    } catch {
      return "12 Dzulqa'dah 1446 H";
    }
  }, [now]);

  if (!tool) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-emerald-950/60 backdrop-blur-sm sm:items-center sm:p-6"
      onClick={onClose}
    >
      <div
        className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-t-3xl bg-white p-6 shadow-2xl sm:rounded-3xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-widest text-amber-600">
              Tools Islami
            </p>
            <h3 className="font-serif text-2xl font-bold text-emerald-950">{tool}</h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-full bg-emerald-50 px-3 py-1 text-sm font-semibold text-emerald-800 transition hover:bg-emerald-100"
          >
            Tutup
          </button>
        </div>

        <div className="space-y-4">
          {tool === "Jadwal Sholat" && (
            <div className="space-y-2">
              <p className="text-sm text-slate-500">
                Waktu sekarang:{" "}
                <span className="font-bold text-emerald-800">
                  {now.toLocaleTimeString("id-ID")}
                </span>
              </p>
              {PRAYER_TIMES.map(([label, time]) => (
                <div
                  key={label}
                  className="flex items-center justify-between rounded-lg bg-emerald-50 px-3 py-2 text-sm ring-1 ring-emerald-100"
                >
                  <span className="text-slate-600">{label}</span>
                  <span className="font-bold text-emerald-800">{time}</span>
                </div>
              ))}
            </div>
          )}

          {tool === "Kalkulator Zakat" && (
            <div className="space-y-3">
              <Label htmlFor="zakat">Total harta (Rp)</Label>
              <Input
                id="zakat"
                inputMode="numeric"
                value={zakat}
                onChange={(e) => setZakat(e.target.value)}
                placeholder="Contoh: 100000000"
              />
              <div className="rounded-xl bg-amber-50 p-4 ring-1 ring-amber-200">
                <p className="text-xs uppercase tracking-wide text-amber-700">Zakat 2,5%</p>
                <p className="text-2xl font-bold text-emerald-900">
                  {zakatValue ? `Rp ${zakatValue}` : "Rp 0"}
                </p>
              </div>
            </div>
          )}

          {tool === "Arabic Pegon" && (
            <div className="space-y-3">
              <Label htmlFor="pegon">Teks Latin</Label>
              <Textarea
                id="pegon"
                value={pegon}
                onChange={(e) => setPegon(e.target.value)}
                placeholder="Tulis teks latin di sini..."
              />
              <div className="rounded-xl bg-emerald-50 p-4 text-right text-2xl ring-1 ring-emerald-100">
                {toPegon(pegon) || "—"}
              </div>
            </div>
          )}

          {tool === "Arabic Keyboard" && (
            <div className="space-y-3">
              <Label htmlFor="arabic">Teks Arab</Label>
              <Textarea
                id="arabic"
                dir="rtl"
                value={arabic}
                onChange={(e) => setArabic(e.target.value)}
                placeholder="اكتب هنا..."
                className="text-right text-xl"
              />
              <div className="flex flex-wrap gap-2">
                {ARABIC_KEYS.map((ch) => (
                  <button
                    key={ch}
                    onClick={() => setArabic((v) => v + ch)}
                    className="h-10 w-10 rounded-lg bg-emerald-50 text-lg text-emerald-900 ring-1 ring-emerald-100 transition hover:bg-emerald-100"
                  >
                    {ch}
                  </button>
                ))}
              </div>
              <Button
                variant="outline"
                onClick={() => setArabic("")}
                className="w-full border-emerald-200 text-emerald-800"
              >
                Hapus
              </Button>
            </div>
          )}

          {tool === "Wirid & Do'a" && (
            <ul className="space-y-2">
              {WIRID.map((w) => (
                <li
                  key={w}
                  className="rounded-lg bg-emerald-50 px-3 py-2 text-sm text-emerald-900 ring-1 ring-emerald-100"
                >
                  {w}
                </li>
              ))}
            </ul>
          )}

          {tool === "Hadist Bukhori" && (
            <ul className="space-y-3">
              {HADITS.map((h) => (
                <li
                  key={h}
                  className="rounded-xl bg-amber-50 p-4 text-sm text-emerald-900 ring-1 ring-amber-100"
                >
                  {h}
                </li>
              ))}
            </ul>
          )}

          {tool === "Al-Qur'an Digital" && (
            <div className="space-y-3">
              {surah ? (
                <div className="rounded-xl bg-emerald-50 p-4 ring-1 ring-emerald-100">
                  <div className="mb-2 flex items-center justify-between">
                    <p className="font-semibold text-emerald-900">{surah}</p>
                    <button
                      onClick={() => setSurah(null)}
                      className="text-xs font-semibold text-emerald-700 hover:underline"
                    >
                      Kembali
                    </button>
                  </div>
                  <p dir="rtl" className="text-right text-2xl leading-loose text-emerald-950">
                    بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ
                  </p>
                  <p className="mt-2 text-sm text-slate-600">
                    Dengan nama Allah Yang Maha Pengasih, Maha Penyayang.
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-2">
                  {SURAHS.map(([s, a]) => (
                    <button
                      key={s}
                      onClick={() => setSurah(s)}
                      className="rounded-lg bg-emerald-50 px-3 py-2 text-left text-sm ring-1 ring-emerald-100 transition hover:bg-emerald-100"
                    >
                      <span className="block font-semibold text-emerald-900">{s}</span>
                      <span className="text-xs text-slate-500">{a}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {tool === "Murottal 30 Juz" && (
            <div className="space-y-3">
              <div className="flex items-center gap-3 rounded-xl bg-emerald-50 p-4 ring-1 ring-emerald-100">
                <button
                  onClick={() => setPlaying((p) => !p)}
                  className="flex h-12 w-12 items-center justify-center rounded-full bg-emerald-700 text-white transition hover:bg-emerald-800"
                >
                  {playing ? "❚❚" : "▶"}
                </button>
                <div>
                  <p className="font-semibold text-emerald-900">Juz {juz} — Murottal</p>
                  <p className="text-xs text-slate-500">Mishary Rashid Alafasy</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Button
                  variant="outline"
                  onClick={() => setJuz((j) => Math.max(1, j - 1))}
                  className="border-emerald-200 text-emerald-800"
                >
                  −
                </Button>
                <span className="flex-1 text-center text-sm font-semibold text-emerald-900">
                  Juz {juz} / 30
                </span>
                <Button
                  variant="outline"
                  onClick={() => setJuz((j) => Math.min(30, j + 1))}
                  className="border-emerald-200 text-emerald-800"
                >
                  +
                </Button>
              </div>
            </div>
          )}

          {tool === "Kalender Hijriah" && (
            <div className="space-y-2 text-sm">
              <div className="flex justify-between rounded-lg bg-emerald-50 px-3 py-2 ring-1 ring-emerald-100">
                <span className="text-slate-600">Masehi</span>
                <span className="font-bold text-emerald-800">
                  {now.toLocaleDateString("id-ID", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </span>
              </div>
              <div className="flex justify-between rounded-lg bg-emerald-50 px-3 py-2 ring-1 ring-emerald-100">
                <span className="text-slate-600">Hijriah</span>
                <span className="font-bold text-emerald-800">{hijri}</span>
              </div>
              <div className="flex justify-between rounded-lg bg-emerald-50 px-3 py-2 ring-1 ring-emerald-100">
                <span className="text-slate-600">Jawa</span>
                <span className="font-bold text-emerald-800">
                  {now.toLocaleDateString("id-ID", { weekday: "long" })}
                </span>
              </div>
            </div>
          )}

          {tool === "Arabic Calligraphy Pro" && (
            <div className="space-y-3">
              <Label htmlFor="calli">Teks Kaligrafi</Label>
              <Input
                id="calli"
                dir="rtl"
                value={calli}
                onChange={(e) => setCalli(e.target.value)}
                className="text-right text-lg"
              />
              <canvas
                ref={canvasRef}
                width={400}
                height={200}
                className="w-full rounded-xl ring-1 ring-emerald-100"
              />
              <p className="text-xs text-slate-500">
                Pratinjau vektor langsung — ubah teks untuk memperbarui kanvas.
              </p>
            </div>
          )}

          {tool === "WebOffice Suite" && (
            <div className="space-y-3">
              <Label htmlFor="note">Catatan Cepat</Label>
              <Textarea
                id="note"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="Tulis catatan, draf, atau agenda..."
                className="min-h-32"
              />
              <p className="text-xs text-slate-500">
                {note.trim() ? `${note.trim().split(/\s+/).length} kata` : "0 kata"}
              </p>
            </div>
          )}

          {tool === "Khazanah Kitab" && (
            <div className="space-y-3">
              {kitab ? (
                <div className="rounded-xl bg-emerald-50 p-4 ring-1 ring-emerald-100">
                  <div className="mb-2 flex items-center justify-between">
                    <p className="font-semibold text-emerald-900">{kitab}</p>
                    <button
                      onClick={() => setKitab(null)}
                      className="text-xs font-semibold text-emerald-700 hover:underline"
                    >
                      Kembali
                    </button>
                  </div>
                  <p className="text-sm text-slate-600">
                    Terjemahan dan kajian teks klasik tersedia lengkap. Pilih bab untuk membaca
                    lebih lanjut.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {["Ihya' Ulumuddin", "Riyadhus Shalihin", "Al-Hikam", "Bidayatul Hidayah"].map(
                    (k) => (
                      <button
                        key={k}
                        onClick={() => setKitab(k)}
                        className="w-full rounded-lg bg-emerald-50 px-3 py-2 text-left text-sm font-semibold text-emerald-900 ring-1 ring-emerald-100 transition hover:bg-emerald-100"
                      >
                        {k}
                      </button>
                    )
                  )}
                </div>
              )}
            </div>
          )}

          {!HANDLED.includes(tool) && (
            <div className="rounded-xl bg-emerald-50 p-4 text-sm text-slate-600 ring-1 ring-emerald-100">
              Modul <span className="font-semibold text-emerald-800">{tool}</span> siap digunakan.
              Konten lengkap akan ditampilkan di sini.
            </div>
          )}
        </div>

        <div className="mt-5">
          <AdSlot variant="inline" />
        </div>

        <Button
          onClick={onClose}
          className="mt-4 w-full bg-emerald-700 font-semibold hover:bg-emerald-800"
        >
          Selesai
        </Button>
      </div>
    </div>
  );
}