import { LOGO_URL, FOOTER_GROUPS } from "@/data/content";

export function Footer() {
  return (
    <footer className="border-t border-emerald-900/20 bg-emerald-950 text-emerald-50">
      <div className="mx-auto grid w-full max-w-6xl grid-cols-1 gap-8 px-4 py-12 sm:grid-cols-2 lg:grid-cols-5">
        <div className="lg:col-span-1">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center overflow-hidden rounded-full border-2 border-amber-400 bg-white">
              <img src={LOGO_URL} alt="ALHIKMAH" className="h-full w-full object-cover" />
            </span>
            <p className="text-lg font-bold tracking-wide">ALHIKMAH</p>
          </div>
          <p className="mt-4 text-sm text-emerald-100/70">
            Berita, kajian, artikel dan tools Islami. Media Islam yang memadukan warta, kajian,
            khazanah budaya dan alat bantu ibadah.
          </p>
        </div>

        {FOOTER_GROUPS.map((group) => (
          <div key={group.title}>
            <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-amber-400">
              {group.title}
            </p>
            <ul className="space-y-2 text-sm text-emerald-100/80">
              {group.items.map((l) => (
                <li key={l}>
                  <a href="#" className="transition hover:text-amber-300">
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-white/10 py-4 text-center text-xs text-emerald-100/60">
        &copy; {new Date().getFullYear()} ALHIKMAH — alhikmah.my.id. Seluruh hak cipta dilindungi.
      </div>
    </footer>
  );
}