import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Bookmark, Settings, LogOut, HelpCircle } from "lucide-react";

const menu = [
  { id: "archive", icon: Bookmark, label: "Artikel Tersimpan" },
  { id: "settings", icon: Settings, label: "Pengaturan" },
  { id: "help", icon: HelpCircle, label: "Bantuan & FAQ" },
];

type Props = {
  onOpen: (id: string) => void;
};

export function AccountPanel({ onOpen }: Props) {
  return (
    <section className="space-y-4">
      <div className="rounded-2xl bg-gradient-to-br from-emerald-900 to-teal-800 p-5 text-white shadow-md">
        <div className="flex items-center gap-4">
          <Avatar className="h-14 w-14 border-2 border-amber-300/60">
            <AvatarFallback className="bg-emerald-800 text-lg font-bold text-amber-300">
              AH
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-serif text-lg font-bold">Ahlan, Sahabat</p>
            <p className="text-xs text-emerald-50/80">
              Masuk untuk menyimpan kajian favorit
            </p>
          </div>
        </div>
        <Button
          onClick={() => onOpen("join")}
          className="mt-4 w-full rounded-xl bg-amber-400 font-semibold text-emerald-950 hover:bg-amber-300"
        >
          Masuk / Daftar
        </Button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-emerald-100/70 bg-white shadow-sm">
        {menu.map(({ id, icon: Icon, label }, i) => (
          <button
            key={id}
            onClick={() => onOpen(id)}
            className={`flex w-full items-center gap-3 px-4 py-3.5 text-left transition hover:bg-emerald-50/60 ${
              i !== 0 ? "border-t border-slate-100" : ""
            }`}
          >
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-100 text-emerald-800">
              <Icon className="h-4 w-4" />
            </span>
            <span className="text-sm font-medium text-slate-700">{label}</span>
          </button>
        ))}
      </div>

      <button
        onClick={() => onOpen("terms")}
        className="flex w-full items-center justify-center gap-2 rounded-2xl border border-rose-100 bg-rose-50/60 py-3 text-sm font-semibold text-rose-600 transition hover:bg-rose-50"
      >
        <LogOut className="h-4 w-4" />
        Keluar
      </button>

      <p className="pt-2 text-center text-[11px] text-slate-400">
        ALHIKMAH · v1.0 · alhikmah.my.id
      </p>
    </section>
  );
}