import { Badge } from "@/components/ui/badge";

const PAGES: Record<
  string,
  { title: string; tag?: string; body: string[] }
> = {
  about: {
    title: "Tentang ALHIKMAH",
    tag: "Profil",
    body: [
      "ALHIKMAH adalah platform digital Islami yang menyajikan warta, kajian, artikel budaya, serta aneka tools Islami gratis dalam satu ekosistem terpadu.",
      "Visi kami: menjadi rujukan literasi Islam yang ramah, akurat, dan mudah diakses oleh seluruh lapisan masyarakat.",
      "Misi: menyediakan konten keislaman berkualitas, mengembangkan tools digital bermanfaat, dan membangun komunitas pembelajar yang tumbuh bersama.",
    ],
  },
  contact: {
    title: "Kontak",
    tag: "Hubungi Kami",
    body: [
      "Email redaksi: redaksi@alhikmah.my.id",
      "Kerja sama & iklan: partner@alhikmah.my.id",
      "Kami merespons setiap pesan dalam 1×24 jam kerja.",
    ],
  },
  advertise: {
    title: "Pasang Iklan",
    tag: "Bisnis",
    body: [
      "ALHIKMAH membuka peluang kerja sama pemasangan iklan display, artikel bersponsor, dan kampanye brand.",
      "Kirim proposal kerja sama ke partner@alhikmah.my.id untuk mendapatkan media kit lengkap.",
    ],
  },
  disclaimer: {
    title: "Penafian",
    tag: "Legal",
    body: [
      "Seluruh informasi pada situs ini bersifat edukatif dan tidak merupakan nasihat finansial, hukum, atau medis profesional.",
      "Kami berupaya menyajikan data yang akurat, namun tidak menjamin bebas dari kekeliruan.",
    ],
  },
  editorial: {
    title: "Kebijakan Editorial",
    tag: "Standar",
    body: [
      "Setiap artikel melalui proses verifikasi sumber, penyuntingan, dan pengecekan fakta sebelum diterbitkan.",
      "Kami menjunjung tinggi prinsip keberimbangan, akurasi, dan adab dalam penyampaian informasi.",
    ],
  },
  forum: {
    title: "Forum Diskusi",
    tag: "Komunitas",
    body: [
      "Ruang diskusi publik bagi pengguna untuk bertukar gagasan seputar keislaman, budaya, dan literasi.",
      "Jaga adab: hindari ujaran kebencian, hoaks, dan konten yang melanggar syariat.",
    ],
  },
  join: {
    title: "Bergabung",
    tag: "Komunitas",
    body: [
      "Terbuka bagi penulis, penerjemah, desainer, dan pengembang yang ingin berkontribusi.",
      "Kirim portofolio singkat ke join@alhikmah.my.id dan tim kami akan menghubungi Anda.",
    ],
  },
  license: {
    title: "Lisensi",
    tag: "Open Source",
    body: [
      "Kode sumber proyek ini dirilis di bawah MIT License.",
      "Konten artikel dilisensikan untuk penggunaan non-komersial dengan atribusi kepada ALHIKMAH.",
    ],
  },
  privacy: {
    title: "Kebijakan Privasi",
    tag: "Data",
    body: [
      "Kami menghormati privasi pengguna dan hanya mengumpulkan data yang diperlukan untuk meningkatkan layanan.",
      "Data tidak dijual atau dibagikan kepada pihak ketiga tanpa persetujuan pengguna.",
    ],
  },
  terms: {
    title: "Syarat & Ketentuan",
    tag: "Legal",
    body: [
      "Dengan mengakses situs ini, Anda menyetujui seluruh syarat dan ketentuan yang berlaku.",
      "Penggunaan konten untuk tujuan komersial wajib memperoleh izin tertulis dari pengelola.",
    ],
  },
  archive: {
    title: "Arsip Artikel",
    tag: "Pustaka",
    body: [
      "Kumpulan artikel yang telah diterbitkan, tersusun rapi berdasarkan kategori dan tanggal.",
      "Gunakan pencarian untuk menemukan topik tertentu dengan cepat.",
    ],
  },
  sitemap: {
    title: "Peta Situs",
    tag: "Navigasi",
    body: [
      "Beranda · Kajian · Tools · Akun · Tentang · Kontak · Iklan · Forum · Privasi · Syarat.",
      "Semua halaman dapat diakses langsung dari navigasi utama aplikasi.",
    ],
  },
  search: {
    title: "Pencarian",
    tag: "Cari",
    body: [
      "Cari artikel, kajian, dan kitab dari seluruh koleksi ALHIKMAH.",
      "Gunakan kata kunci singkat untuk hasil yang lebih relevan.",
    ],
  },
  "news-update": {
    title: "Notifikasi",
    tag: "Terbaru",
    body: [
      "Belum ada notifikasi baru.",
      "Aktifkan izin notifikasi untuk menerima warta terbaru langsung di perangkat Anda.",
    ],
  },
  settings: {
    title: "Pengaturan",
    tag: "Preferensi",
    body: [
      "Atur tema, bahasa, dan preferensi notifikasi sesuai kebutuhan Anda.",
      "Pengaturan disimpan secara lokal di perangkat ini.",
    ],
  },
  help: {
    title: "Bantuan & FAQ",
    tag: "Dukungan",
    body: [
      "Bagaimana cara menyimpan artikel? Masuk ke akun lalu tekan ikon simpan.",
      "Bagaimana cara mengubah lokasi jadwal sholat? Buka Pengaturan lalu pilih kota.",
    ],
  },
  khutbah: {
    title: "Menjaga Lisan di Era Digital",
    tag: "Khutbah",
    body: [
      "Lisan adalah cermin hati. Di era digital, jejak kata tersimpan abadi dan dapat dibaca siapa saja.",
      "Islam mengajarkan untuk berkata baik atau diam, sebagaimana sabda Rasulullah ﷺ.",
      "Mari jadikan media sosial sebagai ladang amal, bukan tempat menabur keburukan.",
    ],
  },
  budaya: {
    title: "Jejak Aksara Pegon di Nusantara",
    tag: "Budaya",
    body: [
      "Aksara Pegon menjadi jembatan penyebaran Islam di Nusantara melalui karya ulama pesantren.",
      "Warisan ini masih hidup dalam manuskrip, kitab kuning, dan tradisi pengajian.",
    ],
  },
  hikmah: {
    title: "Sabar sebagai Kekuatan",
    tag: "Hikmah",
    body: [
      "Sabar bukan berarti pasrah tanpa usaha, melainkan menahan diri sambil terus berikhtiar.",
      "Allah bersama orang-orang yang sabar, dan setiap kesulitan disertai kemudahan.",
    ],
  },
  tafsir: {
    title: "Surat Al-Fatihah: Pintu Segala Hikmah",
    tag: "Tafsir",
    body: [
      "Al-Fatihah adalah pembuka Al-Qur'an dan inti dari setiap salat.",
      "Tujuh ayatnya merangkum tauhid, ibadah, dan permohonan petunjuk.",
    ],
  },
  hadits: {
    title: "Hadits Arbain: Niat dan Keikhlasan",
    tag: "Hadits",
    body: [
      "Setiap amal bergantung pada niatnya, dan setiap orang mendapat sesuai apa yang ia niatkan.",
      "Keikhlasan menjadikan amal kecil bernilai besar di sisi Allah.",
    ],
  },
  fiqih: {
    title: "Panduan Salat Jama' dan Qashar",
    tag: "Fiqih",
    body: [
      "Musafir diberi keringanan menjamak dan mengqashar salat sesuai ketentuan syariat.",
      "Perhatikan syarat jarak, durasi perjalanan, dan niat saat memulai salat.",
    ],
  },
  akhlak: {
    title: "Adab kepada Orang Tua",
    tag: "Akhlak",
    body: [
      "Birrul walidain adalah amal yang sangat dicintai Allah setelah salat tepat waktu.",
      "Berbakti kepada orang tua mencakup tutur kata, sikap, dan doa yang terus dipanjatkan.",
    ],
  },
};

export function InfoPage({ id }: { id: string }) {
  const page = PAGES[id];
  if (!page) return null;

  return (
    <section className="space-y-4">
      {page.tag && (
        <Badge
          variant="secondary"
          className="rounded-full bg-emerald-50 text-[10px] font-semibold text-emerald-800"
        >
          {page.tag}
        </Badge>
      )}
      <h1 className="font-serif text-2xl font-bold leading-tight text-emerald-900">
        {page.title}
      </h1>
      <div className="space-y-3">
        {page.body.map((p, i) => (
          <p key={i} className="text-sm leading-relaxed text-slate-600">
            {p}
          </p>
        ))}
      </div>
      <div className="rounded-2xl border border-emerald-100 bg-emerald-50/50 p-4">
        <p className="text-[11px] text-slate-500">
          ALHIKMAH · alhikmah.my.id · Diperbarui secara berkala
        </p>
      </div>
    </section>
  );
}