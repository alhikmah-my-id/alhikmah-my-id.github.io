import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

const kajian = [
  {
    id: "tafsir-fatihah",
    tag: "Tafsir",
    title: "Surat Al-Fatihah: Pintu Segala Hikmah",
    excerpt: "Membedah makna tujuh ayat pembuka dalam Al-Qur'an.",
    tone: "bg-emerald-700",
  },
  {
    id: "hadits-arbain",
    tag: "Hadits",
    title: "Hadits Arbain: Niat dan Keikhlasan",
    excerpt: "Pelajari 42 hadits pilihan sebagai pondasi amal.",
    tone: "bg-amber-600",
  },
  {
    id: "fiqih-jama",
    tag: "Fiqih",
    title: "Panduan Salat Jama' dan Qashar",
    excerpt: "Ketentuan praktis bagi musafir menurut empat mazhab.",
    tone: "bg-teal-700",
  },
  {
    id: "akhlak-ortu",
    tag: "Akhlak",
    title: "Adab kepada Orang Tua",
    excerpt: "Birrul walidain dalam tinjauan Al-Qur'an dan Sunnah.",
    tone: "bg-emerald-700",
  },
];

type Props = {
  onOpen: (id: string) => void;
};

export function KajianPanel({ onOpen }: Props) {
  const [q, setQ] = useState("");
  const filtered = kajian.filter((k) =>
    (k.title + k.tag).toLowerCase().includes(q.toLowerCase())
  );

  return (
    <section className="space-y-4">
      <div className="rounded-2xl bg-gradient-to-br from-emerald-900 to-teal-800 p-5 text-white shadow-md">
        <div className="flex items-center gap-2">
          <BookOpen className="h-5 w-5 text-amber-300" />
          <h2 className="font-serif text-xl font-bold">Kajian Islam</h2>
        </div>
        <p className="mt-1 text-sm text-emerald-50/80">
          Kumpulan kajian pilihan dari para asatidz.
        </p>
      </div>

      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Cari kajian..."
          className="rounded-xl border-emerald-100 bg-white pl-9"
        />
      </div>

      <div className="space-y-3">
        {filtered.map((k) => (
          <button
            key={k.id}
            onClick={() => onOpen(k.id)}
            className="group block w-full overflow-hidden rounded-2xl border border-emerald-100/70 bg-white text-left shadow-sm transition hover:shadow-md active:scale-[0.99]"
          >
            <div className={`h-1.5 w-full ${k.tone}`} />
            <div className="p-4">
              <Badge
                variant="secondary"
                className="mb-2 rounded-full bg-emerald-50 text-[10px] font-semibold text-emerald-800"
              >
                {k.tag}
              </Badge>
              <h3 className="font-serif text-base font-bold text-slate-800 group-hover:text-emerald-800">
                {k.title}
              </h3>
              <p className="mt-1 text-xs text-slate-500">{k.excerpt}</p>
            </div>
          </button>
        ))}
        {filtered.length === 0 && (
          <div className="rounded-2xl border border-dashed border-emerald-200 bg-emerald-50/40 p-8 text-center">
            <p className="text-sm text-slate-500">
              Tidak ada kajian untuk "{q}".
            </p>
          </div>
        )}
      </div>
    </section>
  );
}