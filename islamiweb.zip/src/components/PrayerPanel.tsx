import { useEffect, useState } from "react";
import { Clock, MapPin } from "lucide-react";

const schedule = [
  { name: "Subuh", time: "04:32" },
  { name: "Dzuhur", time: "11:54" },
  { name: "Ashar", time: "15:12" },
  { name: "Maghrib", time: "17:58" },
  { name: "Isya", time: "19:08" },
];

function toMinutes(t: string) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}

export function PrayerPanel() {
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  const nowMin = now.getHours() * 60 + now.getMinutes();
  const next = schedule.find((s) => toMinutes(s.time) > nowMin) ?? schedule[0];

  const clock = now.toLocaleTimeString("id-ID", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });

  return (
    <section className="rounded-2xl border border-emerald-100/70 bg-white p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-100 text-emerald-800">
            <Clock className="h-5 w-5" />
          </span>
          <div>
            <p className="text-xs text-slate-500">Waktu sekarang</p>
            <p className="font-mono text-lg font-bold text-emerald-900">
              {clock}
            </p>
          </div>
        </div>
        <div className="text-right">
          <p className="text-xs text-slate-500">Salat berikutnya</p>
          <p className="text-sm font-bold text-amber-700">
            {next.name} · {next.time}
          </p>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-5 gap-2">
        {schedule.map((s) => {
          const isNext = s.name === next.name;
          return (
            <div
              key={s.name}
              className={`rounded-xl border px-1 py-2 text-center transition ${
                isNext
                  ? "border-emerald-300 bg-emerald-50"
                  : "border-slate-100 bg-slate-50/60"
              }`}
            >
              <p
                className={`text-[10px] font-semibold ${
                  isNext ? "text-emerald-800" : "text-slate-500"
                }`}
              >
                {s.name}
              </p>
              <p
                className={`font-mono text-[11px] ${
                  isNext ? "text-emerald-900" : "text-slate-600"
                }`}
              >
                {s.time}
              </p>
            </div>
          );
        })}
      </div>

      <div className="mt-3 flex items-center gap-1.5 text-[11px] text-slate-400">
        <MapPin className="h-3.5 w-3.5" />
        Jakarta, Indonesia · Metode Kemenag
      </div>
    </section>
  );
}