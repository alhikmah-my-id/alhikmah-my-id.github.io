import { Badge } from "@/components/ui/badge";

const articles = [
  {
    id: "khutbah-lisan",
    tag: "Khutbah",
    title: "Menjaga Lisan di Era Digital",
    excerpt:
      "Bagaimana adab bertutur dalam Islam relevan menghadapi derasnya arus informasi hari ini.",
    read: "6 mnt",
    tone: "bg-emerald-700",
  },
  {
    id: "budaya-pegon",
    tag: "Budaya",
    title: "Jejak Aksara Pegon di Nusantara",
    excerpt:
      "Menelusuri warisan literasi pesantren yang membentuk khazanah keilmuan Islam lokal.",
    read: "9 mnt",
    tone: "bg-amber-600",
  },
  {
    id: "hikmah-sabar",
    tag: "Hikmah",
    title: "Sabar sebagai Kekuatan, Bukan Kelemahan",
    excerpt:
      "Renungan singkat tentang makna sabar dalam menghadapi ujian kehidupan sehari-hari.",
    read: "4 mnt",
    tone: "bg-teal-700",
  },
];

type Props = {
  onOpen: (id: string) => void;
};

export function ArticleFeed({ onOpen }: Props) {
  return (
    <section>
      <div className="mb-3 flex items-end justify-between">
        <div>
          <h2 className="font-serif text-xl font-bold text-emerald-900">
            Warta Terbaru
          </h2>
          <p className="text-xs text-slate-500">Kajian &amp; artikel pilihan</p>
        </div>
        <button
          onClick={() => onOpen("archive")}
          className="text-xs font-semibold text-emerald-700 hover:text-emerald-900"
        >
          Arsip
        </button>
      </div>

      <div className="space-y-3">
        {articles.map((a) => (
          <button
            key={a.id}
            onClick={() => onOpen(a.id)}
            className="group block w-full overflow-hidden rounded-2xl border border-emerald-100/70 bg-white text-left shadow-sm transition hover:shadow-md active:scale-[0.99]"
          >
            <div className={`h-1.5 w-full ${a.tone}`} />
            <div className="p-4">
              <div className="mb-2 flex items-center gap-2">
                <Badge
                  variant="secondary"
                  className="rounded-full bg-emerald-50 text-[10px] font-semibold text-emerald-800"
                >
                  {a.tag}
                </Badge>
                <span className="text-[10px] text-slate-400">{a.read} baca</span>
              </div>
              <h3 className="font-serif text-base font-bold leading-snug text-slate-800 group-hover:text-emerald-800">
                {a.title}
              </h3>
              <p className="mt-1 text-xs leading-relaxed text-slate-500">
                {a.excerpt}
              </p>
            </div>
          </button>
        ))}
      </div>
    </section>
  );
}