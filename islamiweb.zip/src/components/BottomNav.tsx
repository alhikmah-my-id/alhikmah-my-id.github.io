import { Home, BookOpen, Wrench, User } from "lucide-react";

const items = [
  { id: "beranda", label: "Beranda", icon: Home },
  { id: "kajian", label: "Kajian", icon: BookOpen },
  { id: "tools", label: "Tools", icon: Wrench },
  { id: "akun", label: "Akun", icon: User },
];

type Props = {
  active: string;
  onChange: (id: string) => void;
};

export function BottomNav({ active, onChange }: Props) {
  return (
    <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto w-full max-w-md border-t border-emerald-100 bg-white/90 px-2 pb-5 pt-2 backdrop-blur-md sm:max-w-lg">
      <div className="flex items-center justify-around">
        {items.map(({ id, label, icon: Icon }) => {
          const isActive = active === id;
          return (
            <button
              key={id}
              onClick={() => onChange(id)}
              className="flex flex-1 flex-col items-center gap-1 rounded-xl py-1 transition active:scale-95"
            >
              <span
                className={`flex h-9 w-9 items-center justify-center rounded-full transition ${
                  isActive
                    ? "bg-emerald-900 text-amber-300"
                    : "text-slate-400 hover:bg-emerald-50 hover:text-emerald-700"
                }`}
              >
                <Icon className="h-5 w-5" />
              </span>
              <span
                className={`text-[10px] font-medium ${
                  isActive ? "text-emerald-900" : "text-slate-400"
                }`}
              >
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}