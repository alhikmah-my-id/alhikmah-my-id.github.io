import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AdSlot } from "@/components/AdSlot";
import { POPULAR_POSTS, ARCHIVE, LABELS, OLDER_POSTS } from "@/data/content";

const TAGS = ["Al-Qur'an", "Tafsir", "Hadits", "Fiqih", "Tasawuf", "Zakat", "Kaligrafi", "Pegon"];

export function Sidebar() {
  return (
    <aside className="space-y-6">
      <Card className="border-emerald-100 bg-white shadow-sm">
        <CardHeader>
          <CardTitle className="font-serif text-lg text-emerald-950">Popular Post</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {POPULAR_POSTS.map((p, i) => (
            <a
              key={p}
              href="#"
              className="flex gap-3 rounded-lg p-1 transition hover:bg-emerald-50"
            >
              <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-amber-100 text-xs font-bold text-amber-800">
                {i + 1}
              </span>
              <span className="text-sm font-medium text-slate-700 hover:text-emerald-800">
                {p}
              </span>
            </a>
          ))}
        </CardContent>
      </Card>

      <Card className="border-emerald-100 bg-white shadow-sm">
        <CardHeader>
          <CardTitle className="font-serif text-lg text-emerald-950">Archive</CardTitle>
        </CardHeader>
        <CardContent className="space-y-1">
          {ARCHIVE.map(([month, count]) => (
            <a
              key={month}
              href="#"
              className="flex items-center justify-between rounded-lg px-3 py-2 text-sm transition hover:bg-emerald-50"
            >
              <span className="text-slate-600">{month}</span>
              <span className="rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-semibold text-emerald-800">
                {count}
              </span>
            </a>
          ))}
        </CardContent>
      </Card>

      <Card className="border-emerald-100 bg-white shadow-sm">
        <CardHeader>
          <CardTitle className="font-serif text-lg text-emerald-950">Label / Kategori</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {LABELS.map((t) => (
            <span
              key={t}
              className="cursor-pointer rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-semibold text-emerald-800 ring-1 ring-emerald-100 transition hover:bg-emerald-100"
            >
              {t}
            </span>
          ))}
        </CardContent>
      </Card>

      <Card className="border-amber-200 bg-gradient-to-br from-amber-50 to-white shadow-sm">
        <CardHeader>
          <CardTitle className="font-serif text-lg text-emerald-950">Jadwal Sholat</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2 text-sm">
          {[
            ["Subuh", "04:32"],
            ["Dzuhur", "11:48"],
            ["Ashar", "15:06"],
            ["Maghrib", "17:52"],
            ["Isya", "19:04"],
          ].map(([label, time]) => (
            <div
              key={label}
              className="flex items-center justify-between rounded-lg bg-white/70 px-3 py-2 ring-1 ring-amber-100"
            >
              <span className="text-slate-600">{label}</span>
              <span className="font-bold text-emerald-800">{time}</span>
            </div>
          ))}
          <Button className="mt-2 w-full bg-emerald-700 font-semibold hover:bg-emerald-800">
            Lihat Jadwal Lengkap
          </Button>
        </CardContent>
      </Card>

      <AdSlot variant="sidebar" />

      <Card className="border-emerald-100 bg-white shadow-sm">
        <CardHeader>
          <CardTitle className="font-serif text-lg text-emerald-950">Postingan Terlama</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          {OLDER_POSTS.map((p) => (
            <a
              key={p}
              href="#"
              className="block rounded-lg px-2 py-1.5 text-sm text-slate-600 transition hover:bg-emerald-50 hover:text-emerald-800"
            >
              {p}
            </a>
          ))}
        </CardContent>
      </Card>

      <Card className="border-emerald-100 bg-white shadow-sm">
        <CardHeader>
          <CardTitle className="font-serif text-lg text-emerald-950">Jelajahi Topik</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {TAGS.map((t) => (
            <span
              key={t}
              className="cursor-pointer rounded-full bg-amber-50 px-3 py-1.5 text-xs font-semibold text-amber-800 ring-1 ring-amber-100 transition hover:bg-amber-100"
            >
              {t}
            </span>
          ))}
        </CardContent>
      </Card>

      <Card className="border-emerald-100 bg-emerald-900 text-white shadow-sm">
        <CardHeader>
          <CardTitle className="font-serif text-lg">Newsletter Hikmah</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3 text-sm text-emerald-50/90">
          <p>Dapatkan ringkasan kajian dan warta terbaik setiap pekan.</p>
          <Button className="w-full bg-amber-400 font-bold text-emerald-950 hover:bg-amber-300">
            Berlangganan
          </Button>
        </CardContent>
      </Card>
    </aside>
  );
}