import { useEffect, useRef } from "react";

type Props = {
  variant?: "leaderboard" | "inline" | "sidebar";
  label?: string;
};

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

const SIZES: Record<string, { slot: string; cls: string }> = {
  leaderboard: { slot: "1234567890", cls: "min-h-24" },
  inline: { slot: "1234567891", cls: "min-h-64" },
  sidebar: { slot: "1234567892", cls: "min-h-56" },
};

export function AdSlot({ variant = "inline", label = "Iklan" }: Props) {
  const ref = useRef<HTMLModElement | null>(null);

  useEffect(() => {
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch {
      /* adsense not loaded */
    }
  }, []);

  const cfg = SIZES[variant];

  return (
    <div className="w-full">
      <p className="mb-1 text-center text-xs uppercase tracking-widest text-slate-400">{label}</p>
      <div
        className={
          "flex w-full items-center justify-center overflow-hidden rounded-xl border border-dashed border-emerald-200 bg-white/70 " +
          cfg.cls
        }
      >
        <ins
          ref={ref}
          className="adsbygoogle block w-full"
          style={{ display: "block" }}
          data-ad-client="ca-pub-6718454554209533"
          data-ad-slot={cfg.slot}
          data-ad-format="auto"
          data-full-width-responsive="true"
        />
      </div>
    </div>
  );
}