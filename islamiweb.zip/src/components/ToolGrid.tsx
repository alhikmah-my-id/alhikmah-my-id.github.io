import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import type { Tool } from "@/data/content";

type Props = {
  tools: Tool[];
  onOpen: (title: string) => void;
};

export function ToolGrid({ tools, onOpen }: Props) {
  return (
    <section>
      <div className="mb-4 flex items-end justify-between gap-4">
        <div>
          <h2 className="font-serif text-2xl font-bold text-emerald-950">Tools Islami</h2>
          <p className="text-sm text-slate-500">
            {tools.length} tools tersedia — gratis tanpa pendaftaran.
          </p>
        </div>
      </div>

      {tools.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-emerald-300 bg-white p-10 text-center">
          <p className="text-slate-500">Tidak ada tools yang cocok dengan pencarian Anda.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {tools.map((tool) => (
            <button key={tool.title} onClick={() => onOpen(tool.title)} className="text-left">
              <Card className="group h-full cursor-pointer border-emerald-100 bg-white shadow-sm transition hover:-translate-y-0.5 hover:border-emerald-300 hover:shadow-md">
                <CardHeader className="flex-row items-center gap-3 space-y-0">
                  <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-50 text-xl">
                    {tool.icon}
                  </span>
                  <div>
                    <CardTitle className="text-base text-emerald-950">{tool.title}</CardTitle>
                    <span className="text-xs font-semibold uppercase tracking-wide text-amber-600">
                      {tool.group}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-slate-500">{tool.desc}</CardDescription>
                </CardContent>
              </Card>
            </button>
          ))}
        </div>
      )}
    </section>
  );
}