import { Compass } from "lucide-react";

export function QiblaPanel() {
  return (
    <section className="rounded-2xl border border-emerald-100/70 bg-white p-5 shadow-sm">
      <div className="flex items-center gap-2">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-amber-100 text-amber-800">
          <Compass className="h-5 w-5" />
        </span>
        <div>
          <h2 className="font-serif text-lg font-bold text-emerald-900">
            Arah Kiblat
          </h2>
          <p className="text-xs text-slate-500">295° dari Utara (Jakarta)</p>
        </div>
      </div>

      <div className="mt-4 flex items-center justify-center">
        <div className="relative flex h-40 w-40 items-center justify-center rounded-full border-4 border-emerald-100 bg-emerald-50/50">
          <span className="absolute top-1 text-[10px] font-semibold text-slate-400">
            U
          </span>
          <span className="absolute bottom-1 text-[10px] font-semibold text-slate-400">
            S
          </span>
          <span className="absolute left-1 text-[10px] font-semibold text-slate-400">
            B
          </span>
          <span className="absolute right-1 text-[10px] font-semibold text-slate-400">
            T
          </span>
          <div
            className="absolute h-28 w-1 rounded-full bg-gradient-to-t from-transparent to-amber-600"
            style={{ transform: "rotate(295deg)", transformOrigin: "bottom" }}
          />
          <div className="h-3 w-3 rounded-full bg-emerald-900" />
        </div>
      </div>
      <p className="mt-3 text-center text-xs text-slate-400">
        Putar perangkat hingga panah mengarah ke atas.
      </p>
    </section>
  );
}