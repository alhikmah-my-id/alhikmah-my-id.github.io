import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { LOGO_URL, NAV_ITEMS } from "@/data/content";

type Props = {
  query: string;
  onQueryChange: (q: string) => void;
};

export function Header({ query, onQueryChange }: Props) {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-emerald-900/10 bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex w-full max-w-6xl items-center gap-3 px-4 py-3">
        <a href="#" className="flex shrink-0 items-center gap-2">
          <span className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-full border-2 border-amber-400 bg-white">
            <img src={LOGO_URL} alt="ALHIKMAH" className="h-full w-full object-cover" />
          </span>
          <span className="hidden font-serif text-xl font-bold tracking-wide text-emerald-950 sm:block">
            ALHIKMAH
          </span>
        </a>

        <div className="relative ml-auto w-full max-w-xs">
          <Input
            value={query}
            onChange={(e) => onQueryChange(e.target.value)}
            placeholder="Cari tools & artikel..."
            className="h-10 rounded-full border-emerald-200 bg-emerald-50/60 pl-4 text-sm focus-visible:ring-emerald-500"
          />
        </div>

        <Button
          variant="ghost"
          onClick={() => setOpen((v) => !v)}
          className="shrink-0 rounded-full text-emerald-800 hover:bg-emerald-50 lg:hidden"
        >
          {open ? "✕" : "☰"}
        </Button>
      </div>

      <nav className="hidden border-t border-emerald-900/5 lg:block">
        <div className="mx-auto flex w-full max-w-6xl items-center gap-1 overflow-x-auto px-4 py-2">
          {NAV_ITEMS.map((item) => (
            <a
              key={item}
              href="#"
              className="whitespace-nowrap rounded-full px-3 py-1.5 text-sm font-medium text-slate-600 transition hover:bg-emerald-50 hover:text-emerald-800"
            >
              {item}
            </a>
          ))}
        </div>
      </nav>

      {open && (
        <nav className="border-t border-emerald-900/5 bg-white lg:hidden">
          <div className="grid grid-cols-2 gap-1 px-4 py-3">
            {NAV_ITEMS.map((item) => (
              <a
                key={item}
                href="#"
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-emerald-50 hover:text-emerald-800"
              >
                {item}
              </a>
            ))}
          </div>
        </nav>
      )}
    </header>
  );
}