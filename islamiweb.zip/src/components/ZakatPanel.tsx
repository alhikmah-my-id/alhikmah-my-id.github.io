import { useState } from "react";
import { Calculator } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const NISAB = 85_000_000;

function formatRp(n: number) {
  return "Rp " + Math.round(n).toLocaleString("id-ID");
}

export function ZakatPanel() {
  const [harta, setHarta] = useState("");

  const value = Number(harta.replace(/\D/g, "")) || 0;
  const wajib = value >= NISAB;
  const zakat = wajib ? value * 0.025 : 0;

  return (
    <section className="rounded-2xl border border-emerald-100/70 bg-white p-5 shadow-sm">
      <div className="flex items-center gap-2">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-teal-100 text-teal-800">
          <Calculator className="h-5 w-5" />
        </span>
        <div>
          <h2 className="font-serif text-lg font-bold text-emerald-900">
            Kalkulator Zakat
          </h2>
          <p className="text-xs text-slate-500">Zakat maal 2,5%</p>
        </div>
      </div>

      <div className="mt-4 space-y-2">
        <Label htmlFor="harta" className="text-xs text-slate-500">
          Total harta (Rp)
        </Label>
        <Input
          id="harta"
          inputMode="numeric"
          value={harta}
          onChange={(e) => setHarta(e.target.value)}
          placeholder="cth. 100000000"
          className="rounded-xl border-emerald-100"
        />
      </div>

      <div
        className={`mt-4 rounded-xl border p-4 ${
          wajib
            ? "border-emerald-200 bg-emerald-50"
            : "border-slate-100 bg-slate-50/60"
        }`}
      >
        <p className="text-xs text-slate-500">Zakat yang perlu dibayar</p>
        <p className="font-mono text-xl font-bold text-emerald-900">
          {formatRp(zakat)}
        </p>
        <p className="mt-1 text-[11px] text-slate-400">
          {wajib
            ? "Harta telah mencapai nisab."
            : `Nisab ${formatRp(NISAB)} — belum tercapai.`}
        </p>
      </div>
    </section>
  );
}