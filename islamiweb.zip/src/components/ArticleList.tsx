import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import type { Article } from "@/data/content";

type Props = {
  articles: Article[];
  categories: string[];
  activeCategory: string;
  onCategoryChange: (c: string) => void;
};

export function ArticleList({ articles, categories, activeCategory, onCategoryChange }: Props) {
  return (
    <section>
      <div className="mb-4">
        <h2 className="font-serif text-2xl font-bold text-emerald-950">Artikel &amp; Warta</h2>
        <p className="text-sm text-slate-500">Kajian, budaya, dan kabar terbaru dari redaksi.</p>
      </div>

      <div className="mb-5 flex flex-wrap gap-2">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => onCategoryChange(cat)}
            className={
              "rounded-full px-4 py-1.5 text-sm font-semibold transition " +
              (activeCategory === cat
                ? "bg-emerald-700 text-white shadow-sm"
                : "bg-white text-emerald-800 ring-1 ring-emerald-200 hover:bg-emerald-50")
            }
          >
            {cat}
          </button>
        ))}
      </div>

      {articles.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-emerald-300 bg-white p-10 text-center">
          <p className="text-slate-500">Belum ada artikel pada kategori ini.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {articles.map((a) => (
            <Card
              key={a.title}
              className="border-emerald-100 bg-white shadow-sm transition hover:shadow-md"
            >
              <CardHeader>
                <div className="mb-2 flex flex-wrap items-center gap-2 text-xs text-slate-500">
                  <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">
                    {a.category}
                  </Badge>
                  <span>{a.date}</span>
                  <span>&middot;</span>
                  <span>{a.readTime}</span>
                </div>
                <CardTitle className="font-serif text-lg text-emerald-950">{a.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">{a.excerpt}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </section>
  );
}