import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

const PEGON_MAP: Record<string, string> = {
  a: "ا", b: "ب", c: "چ", d: "د", e: "ي", f: "ف", g: "غ", h: "ه",
  i: "ي", j: "ج", k: "ك", l: "ل", m: "م", n: "ن", o: "و", p: "ف",
  q: "ق", r: "ر", s: "س", t: "ت", u: "و", v: "ف", w: "و", x: "كس",
  y: "ي", z: "ز",
};

function toPegon(text: string) {
  return text
    .toLowerCase()
    .split("")
    .map((ch) => PEGON_MAP[ch] ?? ch)
    .join("");
}

const KITAB = [
  { title: "Safinatun Najah", author: "Syaikh Salim bin Sumair", field: "Fiqih" },
  { title: "Al-Hikam", author: "Ibnu Atha'illah", field: "Tasawuf" },
  { title: "Riyadhus Shalihin", author: "Imam An-Nawawi", field: "Hadits" },
  { title: "Tafsir Jalalain", author: "Jalaluddin al-Mahalli", field: "Tafsir" },
];

const JUZ = Array.from({ length: 30 }, (_, i) => i + 1);

export function ToolPage({ id }: { id: string }) {
  const [pegon, setPegon] = useState("");
  const [zakat, setZakat] = useState("");
  const [juz, setJuz] = useState(1);
  const [playing, setPlaying] = useState(false);

  if (id === "arabic-pegon") {
    return (
      <section className="space-y-4">
        <h1 className="font-serif text-2xl font-bold text-emerald-900">
          Arabic Pegon
        </h1>
        <p className="text-sm text-slate-500">
          Konversi aksara Latin ke Arab Pegon untuk literasi pesantren.
        </p>
        <div className="space-y-2">
          <Label className="text-xs text-slate-500">Teks Latin</Label>
          <Textarea
            value={pegon}
            onChange={(e) => setPegon(e.target.value)}
            placeholder="Tulis teks latin di sini..."
            className="min-h-24 rounded-xl border-emerald-100"
          />
        </div>
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
          <p className="mb-1 text-xs font-semibold text-emerald-700">
            Hasil Pegon
          </p>
          <p
            dir="rtl"
            className="min-h-12 text-2xl leading-loose text-emerald-900"
          >
            {pegon ? toPegon(pegon) : "—"}
          </p>
        </div>
      </section>
    );
  }

  if (id === "calligraphy") {
    return (
      <section className="space-y-4">
        <h1 className="font-serif text-2xl font-bold text-emerald-900">
          Arabic Calligraphy Pro
        </h1>
        <p className="text-sm text-slate-500">
          Generator kaligrafi Arab berbasis vektor.
        </p>
        <div className="rounded-2xl border border-emerald-100 bg-white p-6 shadow-sm">
          <p
            dir="rtl"
            className="text-center font-serif text-5xl leading-relaxed text-emerald-900"
          >
            بِسْمِ اللّٰه
          </p>
        </div>
        <div className="grid grid-cols-3 gap-3">
          {["Amiri", "Scheherazade", "Lateef"].map((f) => (
            <button
              key={f}
              className="rounded-xl border border-emerald-100 bg-white py-2 text-xs font-medium text-emerald-800 transition hover:bg-emerald-50 active:scale-95"
            >
              {f}
            </button>
          ))}
        </div>
        <Button className="w-full rounded-xl bg-emerald-900 text-amber-300 hover:bg-emerald-800">
          Ekspor SVG
        </Button>
      </section>
    );
  }

  if (id === "kalender") {
    const now = new Date();
    return (
      <section className="space-y-4">
        <h1 className="font-serif text-2xl font-bold text-emerald-900">
          Kalender
        </h1>
        <p className="text-sm text-slate-500">
          Penanggalan multi-konversi Masehi, Hijriah, dan Jawa.
        </p>
        <div className="space-y-3">
          {[
            {
              label: "Masehi",
              value: now.toLocaleDateString("id-ID", {
                weekday: "long",
                day: "numeric",
                month: "long",
                year: "numeric",
              }),
              tone: "border-emerald-200 bg-emerald-50 text-emerald-900",
            },
            {
              label: "Hijriah",
              value: "15 Jumadil Awal 1447 H",
              tone: "border-amber-200 bg-amber-50 text-amber-900",
            },
            {
              label: "Jawa",
              value: "Selasa Kliwon",
              tone: "border-teal-200 bg-teal-50 text-teal-900",
            },
          ].map((c) => (
            <div key={c.label} className={`rounded-2xl border p-4 ${c.tone}`}>
              <p className="text-xs font-semibold uppercase tracking-wide opacity-70">
                {c.label}
              </p>
              <p className="mt-1 font-serif text-lg font-bold">{c.value}</p>
            </div>
          ))}
        </div>
      </section>
    );
  }

  if (id === "jadwal-sholat") {
    const times = [
      ["Subuh", "04:32"],
      ["Dzuhur", "11:54"],
      ["Ashar", "15:12"],
      ["Maghrib", "17:58"],
      ["Isya", "19:08"],
    ];
    return (
      <section className="space-y-4">
        <h1 className="font-serif text-2xl font-bold text-emerald-900">
          Jadwal Sholat
        </h1>
        <p className="text-sm text-slate-500">
          Pengingat waktu salat fardu · Jakarta, Kemenag.
        </p>
        <div className="overflow-hidden rounded-2xl border border-emerald-100 bg-white shadow-sm">
          {times.map(([name, time], i) => (
            <div
              key={name}
              className={`flex items-center justify-between px-4 py-3.5 ${
                i !== 0 ? "border-t border-slate-100" : ""
              }`}
            >
              <span className="text-sm font-medium text-slate-700">{name}</span>
              <span className="font-mono text-sm font-bold text-emerald-900">
                {time}
              </span>
            </div>
          ))}
        </div>
      </section>
    );
  }

  if (id === "murotal") {
    return (
      <section className="space-y-4">
        <h1 className="font-serif text-2xl font-bold text-emerald-900">
          Murotal 30 Juz
        </h1>
        <p className="text-sm text-slate-500">
          Pemutar audio Al-Qur'an digital interaktif.
        </p>
        <div className="rounded-2xl border border-emerald-100 bg-white p-5 text-center shadow-sm">
          <p className="font-serif text-3xl font-bold text-emerald-900">
            Juz {juz}
          </p>
          <p className="mt-1 text-xs text-slate-500">Murottal pilihan</p>
          <button
            onClick={() => setPlaying((p) => !p)}
            className="mt-4 flex h-14 w-14 mx-auto items-center justify-center rounded-full bg-emerald-900 text-amber-300 transition hover:bg-emerald-800 active:scale-95"
          >
            {playing ? "❚❚" : "▶"}
          </button>
          <p className="mt-2 text-[11px] text-slate-400">
            {playing ? "Memutar..." : "Tekan untuk memutar"}
          </p>
        </div>
        <div className="grid grid-cols-5 gap-2">
          {JUZ.map((n) => (
            <button
              key={n}
              onClick={() => setJuz(n)}
              className={`rounded-xl border py-2 text-xs font-semibold transition active:scale-95 ${
                juz === n
                  ? "border-emerald-300 bg-emerald-50 text-emerald-900"
                  : "border-slate-100 bg-white text-slate-500 hover:bg-emerald-50"
              }`}
            >
              {n}
            </button>
          ))}
        </div>
      </section>
    );
  }

  if (id === "alquran") {
    return (
      <section className="space-y-4">
        <h1 className="font-serif text-2xl font-bold text-emerald-900">
          Al-Qur'an Digital
        </h1>
        <p className="text-sm text-slate-500">
          Mushaf portable untuk dibaca di mana saja.
        </p>
        <div className="rounded-2xl border border-emerald-100 bg-white p-6 shadow-sm">
          <p className="text-center text-xs text-emerald-600">Al-Fatihah · 1</p>
          <p
            dir="rtl"
            className="mt-4 text-center font-serif text-2xl leading-loose text-emerald-900"
          >
            بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ
          </p>
          <p className="mt-4 text-center text-sm text-slate-500">
            "Dengan nama Allah Yang Maha Pengasih, Maha Penyayang."
          </p>
        </div>
      </section>
    );
  }

  if (id === "weboffice") {
    return (
      <section className="space-y-4">
        <h1 className="font-serif text-2xl font-bold text-emerald-900">
          WebOffice Suite
        </h1>
        <p className="text-sm text-slate-500">
          Alat produktivitas perkantoran berbasis web.
        </p>
        <div className="grid grid-cols-2 gap-3">
          {["Dokumen", "Spreadsheet", "Presentasi", "Catatan"].map((t) => (
            <button
              key={t}
              className="rounded-2xl border border-emerald-100 bg-white p-5 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md active:scale-95"
            >
              <p className="font-serif text-base font-bold text-emerald-900">
                {t}
              </p>
              <p className="mt-1 text-[11px] text-slate-400">Buka editor</p>
            </button>
          ))}
        </div>
      </section>
    );
  }

  if (id === "khazanah") {
    return (
      <section className="space-y-4">
        <h1 className="font-serif text-2xl font-bold text-emerald-900">
          Khazanah Kitab
        </h1>
        <p className="text-sm text-slate-500">
          Teks referensi &amp; literatur klasik terpercaya.
        </p>
        <div className="space-y-3">
          {KITAB.map((k) => (
            <div
              key={k.title}
              className="rounded-2xl border border-emerald-100 bg-white p-4 shadow-sm"
            >
              <p className="font-serif text-base font-bold text-emerald-900">
                {k.title}
              </p>
              <p className="text-xs text-slate-500">{k.author}</p>
              <span className="mt-2 inline-block rounded-full bg-amber-50 px-2 py-0.5 text-[10px] font-semibold text-amber-700">
                {k.field}
              </span>
            </div>
          ))}
        </div>
      </section>
    );
  }

  if (id === "zakat") {
    const value = Number(zakat.replace(/\D/g, "")) || 0;
    const wajib = value >= 85_000_000;
    return (
      <section className="space-y-4">
        <h1 className="font-serif text-2xl font-bold text-emerald-900">
          Kalkulator Zakat
        </h1>
        <div className="space-y-2">
          <Label className="text-xs text-slate-500">Total harta (Rp)</Label>
          <Input
            inputMode="numeric"
            value={zakat}
            onChange={(e) => setZakat(e.target.value)}
            placeholder="cth. 100000000"
            className="rounded-xl border-emerald-100"
          />
        </div>
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-4">
          <p className="text-xs text-slate-500">Zakat (2,5%)</p>
          <p className="font-mono text-xl font-bold text-emerald-900">
            Rp {Math.round(wajib ? value * 0.025 : 0).toLocaleString("id-ID")}
          </p>
        </div>
      </section>
    );
  }

  return null;
}