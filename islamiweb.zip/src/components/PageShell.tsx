import { ChevronLeft } from "lucide-react";

type Props = {
  onBack: () => void;
};

export function PageShell({ onBack }: Props) {
  return (
    <header className="sticky top-0 z-20 flex items-center gap-3 border-b border-emerald-100 bg-white/90 px-4 py-3 backdrop-blur-md">
      <button
        onClick={onBack}
        className="flex h-9 w-9 items-center justify-center rounded-full text-emerald-800 transition hover:bg-emerald-50 active:scale-95"
        aria-label="Kembali"
      >
        <ChevronLeft className="h-5 w-5" />
      </button>
      <p className="font-serif text-lg font-bold text-emerald-900">ALHIKMAH</p>
    </header>
  );
}