import { Button } from "@/components/ui/button";
import { LOGO_URL } from "@/data/content";

export function Hero() {
  return (
    <section className="relative overflow-hidden border-b border-emerald-900/10 bg-gradient-to-br from-emerald-900 via-emerald-800 to-emerald-950">
      <div className="pointer-events-none absolute -right-16 -top-16 h-64 w-64 rounded-full bg-amber-400/10 blur-2xl" />
      <div className="pointer-events-none absolute -bottom-24 -left-10 h-72 w-72 rounded-full bg-emerald-400/10 blur-3xl" />

      <div className="mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-8 px-4 py-12 sm:py-16 lg:grid-cols-5">
        <div className="lg:col-span-3">
          <span className="inline-flex items-center gap-2 rounded-full bg-amber-400/15 px-3 py-1 text-xs font-semibold uppercase tracking-widest text-amber-300 ring-1 ring-amber-400/30">
            Platform Islami Terpadu
          </span>
          <h1 className="mt-4 font-serif text-3xl font-bold leading-tight text-white sm:text-5xl">
            Warta, Kajian &amp; Tools Islami dalam Satu Genggaman
          </h1>
          <p className="mt-4 max-w-xl text-sm text-emerald-100/80 sm:text-base">
            ALHIKMAH menghadirkan berita, kajian, artikel budaya, serta tools Islami gratis —
            Al-Qur'an digital, jadwal sholat, kaligrafi, dan banyak lagi.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button className="bg-amber-400 font-bold text-emerald-950 hover:bg-amber-300">
              Jelajahi Tools
            </Button>
            <Button
              variant="outline"
              className="border-emerald-300/40 bg-transparent font-semibold text-emerald-50 hover:bg-white/10 hover:text-white"
            >
              Baca Artikel
            </Button>
          </div>
        </div>

        <div className="flex justify-center lg:col-span-2">
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-amber-400/20 blur-2xl" />
            <span className="relative flex h-40 w-40 items-center justify-center overflow-hidden rounded-full border-4 border-amber-400 bg-white shadow-2xl sm:h-52 sm:w-52">
              <img src={LOGO_URL} alt="ALHIKMAH" className="h-full w-full object-cover" />
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}