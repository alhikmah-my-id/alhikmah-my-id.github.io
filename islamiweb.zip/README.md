# ALHIKMAH

ALHIKMAH: warta, kajian Islam, artikel budaya, dan tools Islami gratis.

## Struktur
- `generator.py` — generator static website (membangun semua halaman dari `data/*.json`)
- `data/` — sumber data JSON (artikel, tools, jadwal sholat, quran)
- `assets/logo.png` — logo utama
- `css/style.css` — stylesheet global
- `js/` — JavaScript fitur tools
- `tools/` — halaman tools (dibangun otomatis)
- `articles/`, `about/`, `contact/`, `privacy/`, `terms/` — halaman statis
- `.github/workflows/deploy.yml` — deploy otomatis ke Cloudflare Pages

## Setup lokal