// Placeholder JS sitemap generator (opsional).
// Jalankan dengan Node: node generate-sitemap.js
const fs = require("fs");

const BASE = "https://alhikmah.my.id";
const pages = ["/", "/articles/", "/tools/", "/about/", "/contact/"];

const xml =
  '<?xml version="1.0" encoding="UTF-8"?>\n' +
  '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' +
  pages.map((p) => `  <url><loc>${BASE}${p}</loc></url>`).join("\n") +
  "\n</urlset>\n";

fs.writeFileSync("sitemap.xml", xml);
console.log("sitemap.xml generated");