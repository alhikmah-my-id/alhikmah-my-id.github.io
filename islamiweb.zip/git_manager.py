"""Helper git sederhana untuk workflow ALHIKMAH."""
import subprocess


def run(*args: str) -> str:
    result = subprocess.run(["git", *args], capture_output=True, text=True)
    return result.stdout.strip() or result.stderr.strip()


def status() -> str:
    return run("status", "--short")


def commit(message: str) -> str:
    run("add", "-A")
    return run("commit", "-m", message)


if __name__ == "__main__":
    print(status())