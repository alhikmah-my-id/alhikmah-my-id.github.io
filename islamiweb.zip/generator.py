"""ALHIKMAH static site generator.

Membangun seluruh halaman statis dari template + data JSON.
Jalankan: python generator.py
"""
from __future__ import annotations

import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).parent
BASE_URL = "https://alhikmah.my.id"
OUT = ROOT

# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_json(name: str, default):
    path = ROOT / "data" / name
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


ARTICLES = load_json("articles.json", [])
TOOLS = load_json("tools.json", [])

# ---------------------------------------------------------------------------
# Layout
# ---------------------------------------------------------------------------

NAV = [
    ("Beranda", "/"),
    ("Artikel", "/articles/"),
    ("Tools", "/tools/"),
    ("Tentang", "/about/"),
    ("Kontak", "/contact/"),
]

TOOL_LINKS = [
    ("quran.html", "Al-Qur'an Digital"),
    ("prayer.html", "Jadwal Sholat"),
    ("kiblat.html", "Arah Kiblat"),
    ("zakat.html", "Kalkulator Zakat"),
    ("arabic-pegon.html", "Arabic Pegon"),
    ("calligraphy.html", "Calligraphy Pro"),
    ("calendar.html", "Kalender"),
    ("hijri.html", "Kalender Hijriah"),
    ("murottal.html", "Murottal 30 Juz"),
    ("tafsir.html", "Tafsir"),
    ("hadits.html", "Hadits"),
    ("fiqh.html", "Fiqih"),
    ("doah.html", "Doa & Dzikir"),
    ("qurban.html", "Qurban"),
    ("kitab.html", "Khazanah Kitab"),
]


def head(title: str, description: str, canonical: str, depth: int = 0) -> str:
    prefix = "../" * depth
    return f"""<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <title>{title}</title>
  <meta name="description" content="{description}" />
  <meta name="theme-color" content="#0b6b4f" />
  <link rel="icon" href="{prefix}favicon.png" />
  <link rel="apple-touch-icon" href="{prefix}assets/logo.png" />
  <link rel="manifest" href="{prefix}manifest.json" />
  <link rel="canonical" href="{BASE_URL}{canonical}" />
  <meta property="og:type" content="website" />
  <meta property="og:site_name" content="ALHIKMAH" />
  <meta property="og:title" content="{title}" />
  <meta property="og:description" content="{description}" />
  <meta property="og:url" content="{BASE_URL}{canonical}" />
  <meta property="og:image" content="{BASE_URL}/images.jpg" />
  <meta name="twitter:card" content="summary_large_image" />
  <link rel="stylesheet" href="{prefix}css/style.css" />
</head>"""


def topbar(depth: int = 0) -> str:
    prefix = "../" * depth
    nav = "".join(
        f'<a href="{prefix}{href.lstrip("/")}">{label}</a>' for label, href in NAV
    )
    return f"""<header class="topbar">
    <div class="container topbar-inner">
      <a class="brand" href="{prefix}index.html">
        <span class="brand-mark"><img src="{prefix}assets/logo.png" alt="ALHIKMAH" /></span>
        <span>ALHIKMAH</span>
      </a>
      <nav class="nav">{nav}</nav>
    </div>
  </header>"""


def footer(depth: int = 0) -> str:
    prefix = "../" * depth
    return f"""<footer>
    <div class="container footer-grid">
      <div>
        <h4>ALHIKMAH</h4>
        <p>Warta, kajian, dan tools Islami gratis untuk semua.</p>
      </div>
      <div>
        <h4>Navigasi</h4>
        <ul>
          <li><a href="{prefix}index.html">Beranda</a></li>
          <li><a href="{prefix}articles/index.html">Artikel</a></li>
          <li><a href="{prefix}tools/index.html">Tools</a></li>
        </ul>
      </div>
      <div>
        <h4>Info</h4>
        <ul>
          <li><a href="{prefix}about/index.html">Tentang</a></li>
          <li><a href="{prefix}contact/index.html">Kontak</a></li>
          <li><a href="{prefix}privacy/index.html">Privasi</a></li>
          <li><a href="{prefix}terms/index.html">Syarat</a></li>
        </ul>
      </div>
      <div>
        <h4>Kontak</h4>
        <p>redaksi@alhikmah.my.id</p>
        <p>partner@alhikmah.my.id</p>
      </div>
    </div>
    <div class="container footer-bottom">
      <span>&copy; <span data-current-year></span> ALHIKMAH &middot; alhikmah.my.id</span>
      <span>Dibuat dengan semangat literasi Islam</span>
    </div>
  </footer>"""


def scripts(depth: int, extra: list[str] | None = None) -> str:
    prefix = "../" * depth
    tags = [f'<script src="{prefix}js/app.js"></script>']
    for s in extra or []:
        tags.append(f'<script src="{prefix}js/{s}"></script>')
    return "\n  ".join(tags)


def page(title: str, description: str, canonical: str, body: str, depth: int = 0,
         extra_js: list[str] | None = None) -> str:
    return f"""{head(title, description, canonical, depth)}
<body>
  {topbar(depth)}
  {body}
  {footer(depth)}
  {scripts(depth, extra_js)}
</body>
</html>
"""


# ---------------------------------------------------------------------------
# Page builders
# ---------------------------------------------------------------------------

def build_home() -> str:
    cards = "".join(
        f"""<article class="article-card">
          <img src="images.jpg" alt="{a['title']}" />
          <div class="article-card-body">
            <div class="meta-row"><span class="pill">{a.get('tag','Artikel')}</span><span>{a.get('read','5 mnt')}</span></div>
            <h3>{a['title']}</h3>
            <p>{a.get('excerpt','')}</p>
          </div>
        </article>"""
        for a in ARTICLES[:6]
    )

    tool_cards = "".join(
        f'<a class="tool-card" href="tools/{slug}"><h3>{name}</h3><p>{TOOLS_BY_SLUG.get(slug, {}).get("desc", "Tools Islami gratis.")}</p></a>'
        for slug, name in TOOL_LINKS[:8]
    )

    body = f"""<section class="hero">
    <div class="container hero-inner">
      <div>
        <span class="hero-badge">Ahlan wa Sahlan</span>
        <h1>Hikmah dalam Setiap Kata</h1>
        <p>Warta, kajian Islam, artikel budaya, dan tools Islami gratis dalam satu ekosistem digital terpadu.</p>
        <div class="cta-row">
          <a class="btn btn-primary" href="tools/index.html">Jelajahi Tools</a>
          <a class="btn btn-secondary" href="articles/index.html">Baca Artikel</a>
        </div>
      </div>
      <div class="hero-card"><img src="images.jpg" alt="ALHIKMAH" /></div>
    </div>
  </section>

  <main class="container main-layout">
    <div class="content-section">
      <section>
        <div class="section-header"><h2>Warta Terbaru</h2><a class="more-link" href="articles/index.html">Arsip</a></div>
        <div class="card-grid">{cards}</div>
      </section>
      <section>
        <div class="section-header"><h2>Tools Islami</h2><a class="more-link" href="tools/index.html">Semua</a></div>
        <div class="tool-grid">{tool_cards}</div>
      </section>
    </div>
    <aside class="sidebar">
      <div class="panel">
        <h3>Kategori</h3>
        <div class="tag-list">
          <a class="tag" href="articles/index.html">Khutbah</a>
          <a class="tag" href="articles/index.html">Budaya</a>
          <a class="tag" href="articles/index.html">Hikmah</a>
          <a class="tag" href="articles/index.html">Fiqih</a>
          <a class="tag" href="articles/index.html">Tafsir</a>
        </div>
      </div>
      <div class="panel">
        <h3>Bagikan</h3>
        <div class="share-box">
          <a href="https://wa.me/?text={BASE_URL}/">WhatsApp</a>
          <a href="https://t.me/share/url?url={BASE_URL}/">Telegram</a>
          <a href="https://twitter.com/intent/tweet?url={BASE_URL}/">X</a>
        </div>
      </div>
    </aside>
  </main>"""
    return page("ALHIKMAH - Berita, kajian, artikel dan tools Islami",
                "ALHIKMAH: warta, kajian Islam, artikel budaya, dan tools Islami gratis.",
                "/", body, 0)


def build_articles() -> str:
    cards = "".join(
        f"""<article class="article-card">
          <img src="../images.jpg" alt="{a['title']}" />
          <div class="article-card-body">
            <div class="meta-row"><span class="pill">{a.get('tag','Artikel')}</span><span>{a.get('read','5 mnt')}</span></div>
            <h3>{a['title']}</h3>
            <p>{a.get('excerpt','')}</p>
          </div>
        </article>"""
        for a in ARTICLES
    )
    body = f"""<main class="container main-layout">
    <div class="content-section">
      <div class="section-header"><h2>Artikel &amp; Kajian</h2></div>
      <div class="card-grid">{cards}</div>
    </div>
    <aside class="sidebar">
      <div class="panel">
        <h3>Kategori</h3>
        <div class="tag-list">
          <a class="tag" href="index.html">Khutbah</a>
          <a class="tag" href="index.html">Budaya</a>
          <a class="tag" href="index.html">Hikmah</a>
          <a class="tag" href="index.html">Fiqih</a>
          <a class="tag" href="index.html">Tafsir</a>
        </div>
      </div>
    </aside>
  </main>"""
    return page("Artikel - ALHIKMAH", "Kumpulan artikel, kajian, dan warta Islami.",
                "/articles/", body, 1)


def build_tools_index() -> str:
    cards = "".join(
        f'<a class="tool-card" href="{slug}"><h3>{name}</h3><p>{TOOLS_BY_SLUG.get(slug, {}).get("desc", "Tools Islami gratis.")}</p></a>'
        for slug, name in TOOL_LINKS
    )
    body = f"""<main class="container main-layout">
    <div class="content-section">
      <div class="section-header"><h2>Tools Islami</h2></div>
      <div class="tool-grid">{cards}</div>
    </div>
    <aside class="sidebar">
      <div class="panel"><h3>Gratis</h3><p>Seluruh tools dapat digunakan tanpa biaya dan tanpa pendaftaran.</p></div>
    </aside>
  </main>"""
    return page("Tools Islami - ALHIKMAH", "Kumpulan tools Islami gratis.",
                "/tools/", body, 1)


def build_simple(title: str, description: str, canonical: str, depth: int,
                 paragraphs: list[str]) -> str:
    content = "".join(f"<p>{p}</p>" for p in paragraphs)
    body = f"""<main class="container main-layout">
    <div class="content-section">
      <div class="section-header"><h2>{title}</h2></div>
      <div class="panel">{content}</div>
    </div>
    <aside class="sidebar">
      <div class="panel"><h3>Kontak</h3><p>redaksi@alhikmah.my.id</p></div>
    </aside>
  </main>"""
    return page(f"{title} - ALHIKMAH", description, canonical, body, depth)


def build_tool_page(slug: str, name: str, desc: str, extra_js: list[str],
                    body_inner: str) -> str:
    body = f"""<main class="container main-layout" id="{slug}-app">
    <div class="content-section">
      <div class="section-header"><h2>{name}</h2><a class="more-link" href="index.html">Kembali</a></div>
      {body_inner}
    </div>
    <aside class="sidebar">
      <div class="panel"><h3>Tentang</h3><p>{desc}</p></div>
    </aside>
  </main>"""
    return page(f"{name} - ALHIKMAH", desc, f"/tools/{slug}.html", body, 2, extra_js)


# ---------------------------------------------------------------------------
# Tool page templates
# ---------------------------------------------------------------------------

def tool_quran() -> str:
    inner = """<div class="form-box">
        <label for="surah-search">Cari surah</label>
        <input id="surah-search" type="text" placeholder="cth. Yasin, Al-Fatihah..." />
      </div>
      <div id="surah-list" class="tool-grid"></div>
      <div id="surah-view"></div>"""
    return build_tool_page("quran", "Al-Qur'an Digital",
                           "Mushaf Al-Qur'an digital 114 surah lengkap dengan terjemahan.",
                           ["quran.js"], inner)


def tool_prayer() -> str:
    inner = """<div class="form-box">
        <label for="city-select">Pilih kota</label>
        <select id="city-select"></select>
        <p class="meta-row">Waktu sekarang: <strong id="prayer-clock">--:--:--</strong></p>
      </div>
      <div id="prayer-result"></div>"""
    return build_tool_page("prayer", "Jadwal Sholat",
                           "Jadwal sholat real-time per kota di Indonesia.",
                           ["prayer.js"], inner)


def tool_kiblat() -> str:
    inner = """<div class="panel">
        <div class="qibla-compass">
          <span class="qibla-label qibla-n">U</span>
          <span class="qibla-label qibla-s">S</span>
          <span class="qibla-label qibla-w">B</span>
          <span class="qibla-label qibla-e">T</span>
          <div id="qibla-needle" class="qibla-needle"></div>
          <div class="qibla-center"></div>
        </div>
        <p id="qibla-status" class="meta-row">Mendeteksi lokasi Anda...</p>
      </div>"""
    return build_tool_page("kiblat", "Arah Kiblat",
                           "Penunjuk arah kiblat berbasis lokasi perangkat.",
                           ["qibla.js"], inner)


def tool_zakat() -> str:
    inner = """<div class="form-box">
        <label for="zakat-harta">Total harta (Rp)</label>
        <input id="zakat-harta" type="text" inputmode="numeric" placeholder="cth. 100000000" />
        <button id="zakat-hitung" type="button">Hitung Zakat</button>
      </div>
      <div id="zakat-result"></div>"""
    return build_tool_page("zakat", "Kalkulator Zakat",
                           "Hitung zakat maal 2,5% sesuai nisab.",
                           ["zakat.js"], inner)


def tool_pegon() -> str:
    inner = """<div class="form-box">
        <label for="pegon-input">Teks Latin</label>
        <input id="pegon-input" type="text" placeholder="Tulis teks latin..." />
      </div>
      <div class="result-box">
        <p><strong>Hasil Pegon:</strong></p>
        <p id="pegon-output" dir="rtl" class="pegon-output">&mdash;</p>
      </div>"""
    return build_tool_page("arabic-pegon", "Arabic Pegon",
                           "Konversi aksara Latin ke Arab Pegon.",
                           ["pegon.js"], inner)


def tool_calligraphy() -> str:
    inner = """<div class="panel">
        <p dir="rtl" class="ayat-arab">بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ</p>
        <div class="tag-list">
          <span class="tag">Amiri</span>
          <span class="tag">Scheherazade</span>
          <span class="tag">Lateef</span>
        </div>
      </div>"""
    return build_tool_page("calligraphy", "Calligraphy Pro",
                           "Generator kaligrafi Arab berbasis vektor.",
                           [], inner)


def tool_calendar() -> str:
    inner = """<div class="tool-grid">
        <div class="tool-card"><h3>Masehi</h3><p id="kal-masehi">&mdash;</p></div>
        <div class="tool-card"><h3>Hijriah</h3><p id="kal-hijri">&mdash;</p></div>
        <div class="tool-card"><h3>Jawa</h3><p id="kal-jawa">&mdash;</p></div>
      </div>"""
    return build_tool_page("calendar", "Kalender",
                           "Penanggalan multi-konversi Masehi, Hijriah, dan Jawa.",
                           ["kalender.js"], inner)


def tool_hijri() -> str:
    inner = """<div class="panel">
        <p><strong>Tanggal Hijriah hari ini:</strong></p>
        <p id="hijri-today" class="ayat-arab">&mdash;</p>
        <p class="meta-row">Konversi mengikuti kalender Ummul Qura.</p>
      </div>"""
    return build_tool_page("hijri", "Kalender Hijriah",
                           "Konversi tanggal Masehi ke Hijriah.",
                           ["hijri.js"], inner)


def tool_murottal() -> str:
    inner = """<div class="panel">
        <p><strong>Murottal 30 Juz</strong></p>
        <p class="meta-row">Pilih juz untuk memutar murottal.</p>
        <div class="tag-list" id="juz-list"></div>
      </div>"""
    return build_tool_page("murottal", "Murottal 30 Juz",
                           "Pemutar audio Al-Qur'an digital interaktif.",
                           ["murottal.js"], inner)


def tool_tafsir() -> str:
    inner = """<div class="panel">
        <h3>Surat Al-Fatihah</h3>
        <p>Al-Fatihah adalah pembuka Al-Qur'an dan inti dari setiap salat. Tujuh ayatnya merangkum tauhid, ibadah, dan permohonan petunjuk.</p>
      </div>"""
    return build_tool_page("tafsir", "Tafsir",
                           "Kajian tafsir Al-Qur'an pilihan.", [], inner)


def tool_hadits() -> str:
    inner = """<div class="panel">
        <h3>Hadits Arbain #1</h3>
        <p>&ldquo;Sesungguhnya setiap amal bergantung pada niatnya.&rdquo;</p>
        <p class="meta-row">Riwayat Bukhari &amp; Muslim</p>
      </div>"""
    return build_tool_page("hadits", "Hadits",
                           "Kumpulan hadits pilihan sebagai pondasi amal.", [], inner)


def tool_fiqh() -> str:
    inner = """<div class="panel">
        <h3>Salat Jama' dan Qashar</h3>
        <p>Musafir diberi keringanan menjamak dan mengqashar salat sesuai ketentuan syariat.</p>
      </div>"""
    return build_tool_page("fiqh", "Fiqih",
                           "Panduan fiqih praktis sehari-hari.", [], inner)


def tool_doah() -> str:
    inner = """<div class="panel">
        <p dir="rtl" class="ayat-arab">رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً</p>
        <p class="ayat-latin">Rabbana atina fid-dunya hasanah wa fil-akhirati hasanah.</p>
        <p>&ldquo;Ya Tuhan kami, berilah kami kebaikan di dunia dan kebaikan di akhirat.&rdquo;</p>
      </div>"""
    return build_tool_page("doah", "Doa &amp; Dzikir",
                           "Kumpulan doa dan dzikir harian.", [], inner)


def tool_qurban() -> str:
    inner = """<div class="panel">
        <h3>Panduan Qurban</h3>
        <p>Ketentuan hewan qurban, waktu penyembelihan, dan pembagian daging menurut syariat.</p>
      </div>"""
    return build_tool_page("qurban", "Qurban",
                           "Panduan ibadah qurban sesuai sunnah.", [], inner)


def tool_kitab() -> str:
    inner = """<div class="tool-grid">
        <div class="tool-card"><h3>Safinatun Najah</h3><p>Syaikh Salim bin Sumair &middot; Fiqih</p></div>
        <div class="tool-card"><h3>Al-Hikam</h3><p>Ibnu Atha'illah &middot; Tasawuf</p></div>
        <div class="tool-card"><h3>Riyadhus Shalihin</h3><p>Imam An-Nawawi &middot; Hadits</p></div>
        <div class="tool-card"><h3>Tafsir Jalalain</h3><p>Jalaluddin al-Mahalli &middot; Tafsir</p></div>
      </div>"""
    return build_tool_page("kitab", "Khazanah Kitab",
                           "Teks referensi &amp; literatur klasik terpercaya.", [], inner)


# ---------------------------------------------------------------------------
# Meta files
# ---------------------------------------------------------------------------

def write_sitemap() -> None:
    pages = ["/", "/articles/", "/tools/", "/about/", "/contact/"]
    pages += [f"/tools/{slug}" for slug, _ in TOOL_LINKS]
    lines = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for p in pages:
        lines.append(f"  <url><loc>{BASE_URL}{p}</loc></url>")
    lines.append("</urlset>")
    (OUT / "sitemap.xml").write_text("\n".join(lines), encoding="utf-8")


def write_rss() -> None:
    items = "\n".join(
        f"    <item>\n      <title>{a['title']}</title>\n"
        f"      <link>{BASE_URL}/articles/</link>\n"
        f"      <description>{a.get('excerpt','')}</description>\n    </item>"
        for a in ARTICLES
    )
    rss = (
        '<?xml version="1.0" encoding="UTF-8"?>\n<rss version="2.0">\n  <channel>\n'
        "    <title>ALHIKMAH</title>\n"
        f"    <link>{BASE_URL}/</link>\n"
        "    <description>Warta, kajian Islam, artikel budaya, dan tools Islami gratis.</description>\n"
        f"    <language>id</language>\n{items}\n  </channel>\n</rss>\n"
    )
    (OUT / "rss.xml").write_text(rss, encoding="utf-8")


def write_search_index() -> None:
    data = [{"title": label, "url": href} for label, href in NAV]
    data += [{"title": name, "url": f"/tools/{slug}"} for slug, name in TOOL_LINKS]
    (OUT / "search.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

TOOLS_BY_SLUG = {t.get("slug"): t for t in TOOLS if isinstance(t, dict)}


def write(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def main() -> None:
    write(OUT / "index.html", build_home())
    write(OUT / "articles" / "index.html", build_articles())
    write(OUT / "tools" / "index.html", build_tools_index())

    write(OUT / "about" / "index.html", build_simple(
        "Tentang ALHIKMAH", "Profil, visi, dan misi platform ALHIKMAH.",
        "/about/", 1,
        ["ALHIKMAH adalah platform digital Islami yang menyajikan warta, kajian, artikel budaya, serta aneka tools Islami gratis dalam satu ekosistem terpadu.",
         "<strong>Visi:</strong> menjadi rujukan literasi Islam yang ramah, akurat, dan mudah diakses.",
         "<strong>Misi:</strong> menyediakan konten keislaman berkualitas dan mengembangkan tools digital bermanfaat."]))

    write(OUT / "contact" / "index.html", build_simple(
        "Kontak", "Hubungi tim ALHIKMAH.", "/contact/", 1,
        ["<strong>Email redaksi:</strong> redaksi@alhikmah.my.id",
         "<strong>Kerja sama &amp; iklan:</strong> partner@alhikmah.my.id",
         "Kami merespons setiap pesan dalam 1&times;24 jam kerja."]))

    write(OUT / "privacy" / "index.html", build_simple(
        "Kebijakan Privasi", "Kebijakan privasi ALHIKMAH.", "/privacy/", 1,
        ["Kami menghormati privasi pengguna dan hanya mengumpulkan data yang diperlukan untuk meningkatkan layanan.",
         "Data tidak dijual atau dibagikan kepada pihak ketiga tanpa persetujuan pengguna."]))

    write(OUT / "terms" / "index.html", build_simple(
        "Syarat &amp; Ketentuan", "Syarat dan ketentuan ALHIKMAH.", "/terms/", 1,
        ["Dengan mengakses situs ini, Anda menyetujui seluruh syarat dan ketentuan yang berlaku.",
         "Penggunaan konten untuk tujuan komersial wajib memperoleh izin tertulis."]))

    write(OUT / "tools" / "quran.html", tool_quran())
    write(OUT / "tools" / "prayer.html", tool_prayer())
    write(OUT / "tools" / "kiblat.html", tool_kiblat())
    write(OUT / "tools" / "zakat.html", tool_zakat())
    write(OUT / "tools" / "arabic-pegon.html", tool_pegon())
    write(OUT / "tools" / "calligraphy.html", tool_calligraphy())
    write(OUT / "tools" / "calendar.html", tool_calendar())
    write(OUT / "tools" / "hijri.html", tool_hijri())
    write(OUT / "tools" / "murottal.html", tool_murottal())
    write(OUT / "tools" / "tafsir.html", tool_tafsir())
    write(OUT / "tools" / "hadits.html", tool_hadits())
    write(OUT / "tools" / "fiqh.html", tool_fiqh())
    write(OUT / "tools" / "doah.html", tool_doah())
    write(OUT / "tools" / "qurban.html", tool_qurban())
    write(OUT / "tools" / "kitab.html", tool_kitab())

    write_sitemap()
    write_rss()
    write_search_index()

    print(f"[{datetime.now(timezone.utc).isoformat()}] ALHIKMAH build selesai.")
    print(f"Output: {OUT}")


if __name__ == "__main__":
    main()