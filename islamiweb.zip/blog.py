"""Utilitas blog sederhana untuk ALHIKMAH."""
from dataclasses import dataclass, field
from typing import List


@dataclass
class Post:
    title: str
    slug: str
    tags: List[str] = field(default_factory=list)
    body: str = ""


def render(post: Post) -> str:
    tags = ", ".join(post.tags)
    return f"# {post.title}\n\nTags: {tags}\n\n{post.body}\n"


if __name__ == "__main__":
    p = Post(title="Contoh Artikel", slug="contoh", tags=["hikmah"], body="Isi artikel.")
    print(render(p))