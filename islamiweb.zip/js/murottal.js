document.addEventListener("DOMContentLoaded", () => {
  const list = document.getElementById("juz-list");
  const player = document.getElementById("murottal-player");
  if (!list) return;

  for (let i = 1; i <= 30; i++) {
    const btn = document.createElement("button");
    btn.className = "tag";
    btn.type = "button";
    btn.textContent = `Juz ${i}`;
    btn.addEventListener("click", () => {
      list.querySelectorAll(".tag").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      if (player) {
        player.innerHTML = `<div class="result-box">
          <p><strong>Juz ${i}</strong></p>
          <p class="meta-row">Streaming murottal Juz ${i}.</p>
          <audio controls style="width:100%" src="https://server8.mp3quran.net/afs/${String(i).padStart(3, "0")}.mp3"></audio>
        </div>`;
      }
    });
    list.appendChild(btn);
  }
});