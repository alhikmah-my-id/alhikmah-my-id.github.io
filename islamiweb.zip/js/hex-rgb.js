document.addEventListener("DOMContentLoaded", () => {
  const hex = document.getElementById("hex-input");
  const rgb = document.getElementById("rgb-input");
  const preview = document.getElementById("hex-preview");
  const output = document.getElementById("hex-output");
  if (!hex || !rgb || !preview || !output) return;

  function fromHex() {
    const v = hex.value.trim();
    const m = /^#?([0-9a-f]{6})$/i.exec(v);
    if (!m) {
      output.textContent = "HEX tidak valid.";
      return;
    }
    const n = parseInt(m[1], 16);
    const r = (n >> 16) & 255;
    const g = (n >> 8) & 255;
    const b = n & 255;
    rgb.value = `${r}, ${g}, ${b}`;
    preview.style.background = `#${m[1]}`;
    output.textContent = `rgb(${r}, ${g}, ${b})`;
  }

  function fromRgb() {
    const parts = rgb.value.split(",").map((x) => parseInt(x.trim(), 10));
    if (parts.length !== 3 || parts.some((n) => isNaN(n) || n < 0 || n > 255)) {
      output.textContent = "RGB tidak valid.";
      return;
    }
    const [r, g, b] = parts;
    const h = "#" + [r, g, b].map((n) => n.toString(16).padStart(2, "0")).join("");
    hex.value = h;
    preview.style.background = h;
    output.textContent = h;
  }

  hex.addEventListener("input", fromHex);
  rgb.addEventListener("input", fromRgb);
  fromHex();
});