document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("morse-input");
  const output = document.getElementById("morse-output");
  const to = document.getElementById("morse-to");
  const from = document.getElementById("morse-from");
  if (!input || !output) return;

  const MAP = {
    A: ".-", B: "-...", C: "-.-.", D: "-..", E: ".", F: "..-.", G: "--.", H: "....",
    I: "..", J: ".---", K: "-.-", L: ".-..", M: "--", N: "-.", O: "---", P: ".--.",
    Q: "--.-", R: ".-.", S: "...", T: "-", U: "..-", V: "...-", W: ".--", X: "-..-",
    Y: "-.--", Z: "--..", "0": "-----", "1": ".----", "2": "..---", "3": "...--",
    "4": "....-", "5": ".....", "6": "-....", "7": "--...", "8": "---..", "9": "----.",
  };
  const REV = Object.fromEntries(Object.entries(MAP).map(([k, v]) => [v, k]));

  to.addEventListener("click", () => {
    output.textContent = input.value
      .toUpperCase()
      .split("")
      .map((c) => (c === " " ? "/" : MAP[c] || ""))
      .filter(Boolean)
      .join(" ");
  });

  from.addEventListener("click", () => {
    output.textContent = input.value
      .trim()
      .split(/\s+/)
      .map((c) => (c === "/" ? " " : REV[c] || ""))
      .join("");
  });
});