document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("json-input");
  const output = document.getElementById("json-output");
  const beautify = document.getElementById("json-beautify");
  const minify = document.getElementById("json-minify");
  if (!input || !output) return;

  function run(fn) {
    try {
      const parsed = JSON.parse(input.value);
      output.textContent = fn(parsed);
    } catch (e) {
      output.textContent = "Error: " + e.message;
    }
  }

  beautify.addEventListener("click", () => run((o) => JSON.stringify(o, null, 2)));
  minify.addEventListener("click", () => run((o) => JSON.stringify(o)));
});