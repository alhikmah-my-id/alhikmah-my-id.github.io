document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("calligraphy-input");
  const size = document.getElementById("calligraphy-size");
  const preview = document.getElementById("calligraphy-preview");
  if (!input || !preview) return;

  function update() {
    preview.textContent = input.value || "—";
    preview.style.fontSize = `${size.value}px`;
  }

  input.addEventListener("input", update);
  size.addEventListener("input", update);
});