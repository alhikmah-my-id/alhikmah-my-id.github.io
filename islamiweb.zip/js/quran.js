document.addEventListener("DOMContentLoaded", () => {
  const list = document.getElementById("surah-list");
  const view = document.getElementById("surah-view");
  const search = document.getElementById("surah-search");
  if (!list) return;

  const FALLBACK = [
    { number: 1, name: "Al-Fatihah", englishName: "The Opening", numberOfAyahs: 7 },
    { number: 2, name: "Al-Baqarah", englishName: "The Cow", numberOfAyahs: 286 },
    { number: 18, name: "Al-Kahf", englishName: "The Cave", numberOfAyahs: 110 },
    { number: 36, name: "Yasin", englishName: "Ya Sin", numberOfAyahs: 83 },
    { number: 55, name: "Ar-Rahman", englishName: "The Beneficent", numberOfAyahs: 78 },
    { number: 67, name: "Al-Mulk", englishName: "The Kingdom", numberOfAyahs: 30 },
    { number: 112, name: "Al-Ikhlas", englishName: "Sincerity", numberOfAyahs: 4 },
    { number: 114, name: "An-Nas", englishName: "Mankind", numberOfAyahs: 6 },
  ];

  let surahs = FALLBACK;

  function renderList(items) {
    if (!items.length) {
      list.innerHTML = '<p class="result-box">Tidak ada surah ditemukan.</p>';
      return;
    }
    list.innerHTML = items
      .map(
        (s) => `<button class="tool-card surah-item" data-num="${s.number}">
          <h3>${s.number}. ${s.name}</h3>
          <p>${s.englishName} &middot; ${s.numberOfAyahs} ayat</p>
        </button>`
      )
      .join("");
    list.querySelectorAll(".surah-item").forEach((btn) => {
      btn.addEventListener("click", () => loadSurah(Number(btn.dataset.num)));
    });
  }

  function loadSurah(num) {
    view.innerHTML = '<div class="panel"><p>Memuat surah...</p></div>';
    fetch(`https://equran.id/api/v2/surat/${num}`)
      .then((r) => r.json())
      .then((data) => {
        const s = data && data.data;
        if (!s) throw new Error("no data");
        const ayahs = (s.ayat || [])
          .map(
            (a) => `<div class="ayat-item">
              <p dir="rtl" class="ayat-arab">${a.ar}</p>
              <p class="ayat-latin">${a.tr || ""}</p>
              <p class="ayat-id">${a.idn || ""}</p>
            </div>`
          )
          .join("");
        view.innerHTML = `<div class="panel"><h3>${s.namaLatin} (${s.nama})</h3>
          <p class="meta-row">${s.arti} &middot; ${s.jumlahAyat} ayat &middot; ${s.tempatTurun}</p>
          <div class="ayat-list">${ayahs}</div></div>`;
      })
      .catch(() => {
        view.innerHTML = '<div class="panel"><p>Gagal memuat surah. Periksa koneksi internet Anda.</p></div>';
      });
  }

  if (search) {
    search.addEventListener("input", (e) => {
      const q = e.target.value.toLowerCase();
      renderList(
        surahs.filter(
          (s) => s.name.toLowerCase().includes(q) || s.englishName.toLowerCase().includes(q)
        )
      );
    });
  }

  fetch("https://equran.id/api/v2/surat")
    .then((r) => r.json())
    .then((data) => {
      if (data && Array.isArray(data.data)) {
        surahs = data.data.map((s) => ({
          number: s.nomor,
          name: s.namaLatin,
          englishName: s.arti,
          numberOfAyahs: s.jumlahAyat,
        }));
        renderList(surahs);
      }
    })
    .catch(() => renderList(surahs));

  renderList(surahs);
});