document.addEventListener("DOMContentLoaded", () => {
  const el = document.getElementById("hijri-today");
  if (!el) return;
  const now = new Date();
  try {
    el.textContent = now.toLocaleDateString("id-ID-u-ca-islamic", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  } catch (e) {
    el.textContent = "Kalender Hijriah tidak didukung perangkat ini.";
  }
});