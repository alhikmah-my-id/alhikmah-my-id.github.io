document.addEventListener("DOMContentLoaded", () => {
  const list = document.getElementById("wirid-list");
  const view = document.getElementById("wirid-view");
  const search = document.getElementById("wirid-search");
  if (!list) return;

  const DATA = [
    {
      id: "yasin",
      title: "Yasin",
      desc: "Surat Yasin lengkap 83 ayat",
      arab: "يٰسۤ ۚ",
      latin: "Yaaasiin",
      arti: "Surat Yasin adalah jantung Al-Qur'an yang dianjurkan dibaca pada malam Jumat dan saat menghadapi kesulitan.",
    },
    {
      id: "tahlil",
      title: "Tahlil",
      desc: "Rangkaian dzikir tahlil",
      arab: "لَا إِلٰهَ إِلَّا اللّٰهُ",
      latin: "Laa ilaaha illallaah",
      arti: "Tiada Tuhan selain Allah. Dzikir tahlil merupakan amalan utama yang pahalanya dapat dihadiahkan kepada ahli kubur.",
    },
    {
      id: "maulid",
      title: "Maulid",
      desc: "Shalawat & pujian Nabi",
      arab: "صَلَّى اللّٰهُ عَلَى مُحَمَّد",
      latin: "Shallallaahu 'alaa Muhammad",
      arti: "Semoga Allah melimpahkan shalawat kepada Nabi Muhammad. Bacaan maulid berisi pujian dan sejarah Nabi.",
    },
    {
      id: "hizib",
      title: "Hizib",
      desc: "Hizib & wirid para ulama",
      arab: "حَسْبُنَا اللّٰهُ وَنِعْمَ الْوَكِيْلُ",
      latin: "Hasbunallaahu wa ni'mal wakiil",
      arti: "Cukuplah Allah bagi kami dan Dia sebaik-baik pelindung. Hizib adalah wirid yang disusun para ulama.",
    },
    {
      id: "istighfar",
      title: "Istighfar",
      desc: "Mohon ampunan",
      arab: "أَسْتَغْفِرُ اللّٰهَ الْعَظِيْمَ",
      latin: "Astaghfirullaahal 'adziim",
      arti: "Aku memohon ampun kepada Allah Yang Maha Agung.",
    },
    {
      id: "shalawat",
      title: "Shalawat",
      desc: "Shalawat Nabi",
      arab: "اَللّٰهُمَّ صَلِّ عَلَى سَيِّدِنَا مُحَمَّد",
      latin: "Allaahumma shalli 'alaa sayyidinaa Muhammad",
      arti: "Ya Allah, limpahkanlah shalawat kepada junjungan kami Nabi Muhammad.",
    },
  ];

  function render(items) {
    if (!items.length) {
      list.innerHTML = '<p class="result-box">Tidak ada wirid ditemukan.</p>';
      return;
    }
    list.innerHTML = items
      .map(
        (w) => `<button class="tool-card wirid-item" data-id="${w.id}">
          <h3>${w.title}</h3><p>${w.desc}</p>
        </button>`
      )
      .join("");
    list.querySelectorAll(".wirid-item").forEach((btn) => {
      btn.addEventListener("click", () => show(btn.dataset.id));
    });
  }

  function show(id) {
    const w = DATA.find((x) => x.id === id);
    if (!w) return;
    view.innerHTML = `
      <div class="panel">
        <h3>${w.title}</h3>
        <p dir="rtl" class="ayat-arab">${w.arab}</p>
        <p class="ayat-latin">${w.latin}</p>
        <p>${w.arti}</p>
      </div>`;
  }

  if (search) {
    search.addEventListener("input", (e) => {
      const q = e.target.value.toLowerCase();
      render(DATA.filter((w) => w.title.toLowerCase().includes(q) || w.desc.toLowerCase().includes(q)));
    });
  }

  render(DATA);
});