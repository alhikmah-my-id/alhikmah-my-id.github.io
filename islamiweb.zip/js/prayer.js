document.addEventListener("DOMContentLoaded", () => {
  const select = document.getElementById("city-select");
  const result = document.getElementById("prayer-result");
  const clock = document.getElementById("prayer-clock");
  if (!select || !result) return;

  const CITIES = [
    { id: "1301", name: "Jakarta" },
    { id: "1219", name: "Bandung" },
    { id: "1601", name: "Surabaya" },
    { id: "1401", name: "Yogyakarta" },
    { id: "1101", name: "Medan" },
    { id: "1701", name: "Makassar" },
  ];

  select.innerHTML = CITIES.map((c) => `<option value="${c.id}">${c.name}</option>`).join("");

  function tick() {
    if (!clock) return;
    clock.textContent = new Date().toLocaleTimeString("id-ID");
  }
  tick();
  setInterval(tick, 1000);

  function load(cityId) {
    result.innerHTML = '<div class="panel"><p>Memuat jadwal...</p></div>';
    const today = new Date();
    const y = today.getFullYear();
    const m = String(today.getMonth() + 1).padStart(2, "0");
    const d = String(today.getDate()).padStart(2, "0");
    fetch(`https://api.myquran.com/v2/sholat/jadwal/${cityId}/${y}/${m}/${d}`)
      .then((r) => r.json())
      .then((data) => {
        const j = data && data.data && data.data.jadwal;
        if (!j) throw new Error("no data");
        const rows = [
          ["Imsak", j.imsak],
          ["Subuh", j.subuh],
          ["Terbit", j.terbit],
          ["Dhuha", j.dhuha],
          ["Dzuhur", j.dzuhur],
          ["Ashar", j.ashar],
          ["Maghrib", j.maghrib],
          ["Isya", j.isya],
        ];
        result.innerHTML = `<div class="panel">
          <h3>${data.data.lokasi || ""}</h3>
          <p class="meta-row">${data.data.daerah || ""} &middot; ${d}/${m}/${y}</p>
          <div class="prayer-grid">
            ${rows
              .map(
                ([label, time]) =>
                  `<div class="prayer-item"><span>${label}</span><strong>${time || "-"}</strong></div>`
              )
              .join("")}
          </div>
        </div>`;
      })
      .catch(() => {
        result.innerHTML = '<div class="panel"><p>Gagal memuat jadwal. Periksa koneksi internet Anda.</p></div>';
      });
  }

  select.addEventListener("change", () => load(select.value));
  load(select.value);
});