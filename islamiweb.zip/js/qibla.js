document.addEventListener("DOMContentLoaded", () => {
  const needle = document.getElementById("qibla-needle");
  const status = document.getElementById("qibla-status");
  if (!needle || !status) return;

  const KAABA = { lat: 21.4225, lng: 39.8262 };

  function bearing(lat, lng) {
    const toRad = (d) => (d * Math.PI) / 180;
    const toDeg = (r) => (r * 180) / Math.PI;
    const dLng = toRad(KAABA.lng - lng);
    const y = Math.sin(dLng) * Math.cos(toRad(KAABA.lat));
    const x =
      Math.cos(toRad(lat)) * Math.sin(toRad(KAABA.lat)) -
      Math.sin(toRad(lat)) * Math.cos(toRad(KAABA.lat)) * Math.cos(dLng);
    return (toDeg(Math.atan2(y, x)) + 360) % 360;
  }

  if (!navigator.geolocation) {
    status.textContent = "Perangkat tidak mendukung geolokasi.";
    return;
  }

  navigator.geolocation.getCurrentPosition(
    (pos) => {
      const { latitude, longitude } = pos.coords;
      const deg = bearing(latitude, longitude);
      needle.style.transform = `rotate(${deg}deg)`;
      status.textContent = `Arah kiblat: ${deg.toFixed(1)}° dari utara.`;
    },
    () => {
      status.textContent = "Izin lokasi ditolak. Aktifkan lokasi untuk melihat arah kiblat.";
    }
  );
});