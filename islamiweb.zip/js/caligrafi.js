document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("caligrafi-input");
  const size = document.getElementById("caligrafi-size");
  const preview = document.getElementById("caligrafi-preview");
  if (!input || !preview) return;

  function update() {
    preview.textContent = input.value || "—";
    preview.style.fontSize = `${size.value}px`;
  }

  input.addEventListener("input", update);
  size.addEventListener("input", update);
});