document.addEventListener("DOMContentLoaded", () => {
  const masehi = document.getElementById("kal-masehi");
  const hijri = document.getElementById("kal-hijri");
  const jawa = document.getElementById("kal-jawa");
  if (!masehi) return;

  const now = new Date();

  masehi.textContent = now.toLocaleDateString("id-ID", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  try {
    hijri.textContent = now.toLocaleDateString("id-ID-u-ca-islamic", {
      day: "numeric",
      month: "long",
      year: "numeric",
    });
  } catch (e) {
    hijri.textContent = "Tidak didukung perangkat ini.";
  }

  const PASARAN = ["Legi", "Pahing", "Pon", "Wage", "Kliwon"];
  const JAWA_BULAN = [
    "Sura", "Sapar", "Mulud", "Bakda Mulud", "Jumadil Awal", "Jumadil Akhir",
    "Rejeb", "Ruwah", "Pasa", "Sawal", "Sela", "Besar",
  ];
  const start = new Date(now.getFullYear(), 0, 1);
  const dayOfYear = Math.floor((now - start) / 86400000);
  const pasaran = PASARAN[dayOfYear % 5];
  const bulanJawa = JAWA_BULAN[now.getMonth()];
  jawa.textContent = `${pasaran}, ${now.getDate()} ${bulanJawa} ${now.getFullYear()}`;
});