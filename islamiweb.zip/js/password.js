document.addEventListener("DOMContentLoaded", () => {
  const length = document.getElementById("password-length");
  const output = document.getElementById("password-output");
  const btn = document.getElementById("password-generate");
  if (!length || !output || !btn) return;

  const CHARS =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()_+-=[]{}";

  function generate() {
    const n = Number(length.value);
    let out = "";
    const arr = new Uint32Array(n);
    crypto.getRandomValues(arr);
    for (let i = 0; i < n; i++) out += CHARS[arr[i] % CHARS.length];
    output.textContent = out;
  }

  btn.addEventListener("click", generate);
  generate();
});