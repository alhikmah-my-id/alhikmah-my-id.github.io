document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("pegon-input");
  const output = document.getElementById("pegon-output");
  if (!input || !output) return;

  const MAP = {
    a: "ا", b: "ب", c: "چ", d: "د", e: "ي", f: "ف", g: "ݢ", h: "ه",
    i: "ي", j: "ج", k: "ک", l: "ل", m: "م", n: "ن", o: "و", p: "ڤ",
    q: "ق", r: "ر", s: "س", t: "ت", u: "و", v: "ۏ", w: "و", x: "کس",
    y: "ي", z: "ز", " ": " ",
  };

  input.addEventListener("input", () => {
    const text = input.value.toLowerCase();
    const out = text
      .split("")
      .map((c) => MAP[c] || c)
      .join("");
    output.textContent = out || "—";
  });
});