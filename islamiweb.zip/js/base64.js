document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("base64-input");
  const output = document.getElementById("base64-output");
  const enc = document.getElementById("base64-encode");
  const dec = document.getElementById("base64-decode");
  if (!input || !output) return;

  enc.addEventListener("click", () => {
    try {
      output.textContent = btoa(unescape(encodeURIComponent(input.value)));
    } catch (e) {
      output.textContent = "Error: " + e.message;
    }
  });

  dec.addEventListener("click", () => {
    try {
      output.textContent = decodeURIComponent(escape(atob(input.value.trim())));
    } catch (e) {
      output.textContent = "Error: " + e.message;
    }
  });
});