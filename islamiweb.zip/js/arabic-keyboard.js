document.addEventListener("DOMContentLoaded", () => {
  const keys = document.getElementById("arabic-keys");
  const output = document.getElementById("arabic-output");
  if (!keys || !output) return;

  const LETTERS = [
    "ا","ب","ت","ث","ج","ح","خ","د","ذ","ر","ز","س","ش","ص","ض","ط","ظ","ع","غ","ف","ق","ك","ل","م","ن","ه","و","ي","ء","ة","ى",
  ];

  function render() {
    keys.innerHTML = LETTERS.map(
      (l) => `<button type="button" class="tag arabic-key">${l}</button>`
    ).join("") + '<button type="button" class="tag arabic-key arabic-space">spasi</button>' +
      '<button type="button" class="tag arabic-key arabic-del">hapus</button>';

    keys.querySelectorAll(".arabic-key").forEach((btn) => {
      btn.addEventListener("click", () => {
        if (btn.classList.contains("arabic-space")) {
          output.value += " ";
        } else if (btn.classList.contains("arabic-del")) {
          output.value = output.value.slice(0, -1);
        } else {
          output.value += btn.textContent;
        }
      });
    });
  }

  render();
});