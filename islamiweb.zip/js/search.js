document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("site-search");
  const results = document.getElementById("site-search-results");
  if (!input || !results) return;

  let index = [];

  fetch("/search.json")
    .then((r) => r.json())
    .then((data) => {
      index = data;
    })
    .catch(() => {
      index = [];
    });

  input.addEventListener("input", () => {
    const q = input.value.trim().toLowerCase();
    if (!q) {
      results.innerHTML = "";
      return;
    }
    const matches = index.filter((item) =>
      item.title.toLowerCase().includes(q)
    );
    results.innerHTML = matches.length
      ? matches
          .map(
            (m) =>
              `<a class="tool-card" href="${m.url}"><h3>${m.title}</h3></a>`
          )
          .join("")
      : '<p class="result-box">Tidak ada hasil.</p>';
  });
});