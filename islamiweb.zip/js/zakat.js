document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("zakat-harta");
  const btn = document.getElementById("zakat-hitung");
  const result = document.getElementById("zakat-result");
  if (!input || !btn || !result) return;

  const NISAB = 85 * 1350000; // 85 gram emas, asumsi Rp1.350.000/gram

  function format(n) {
    return "Rp " + n.toLocaleString("id-ID");
  }

  btn.addEventListener("click", () => {
    const raw = input.value.replace(/[^\d]/g, "");
    const harta = Number(raw);
    if (!harta) {
      result.innerHTML = '<div class="result-box">Masukkan total harta terlebih dahulu.</div>';
      return;
    }
    const wajib = harta >= NISAB;
    const zakat = wajib ? harta * 0.025 : 0;
    result.innerHTML = `<div class="result-box">
      <p><strong>Total harta:</strong> ${format(harta)}</p>
      <p><strong>Nisab (85 gr emas):</strong> ${format(NISAB)}</p>
      <p><strong>Status:</strong> ${wajib ? "Wajib zakat" : "Belum mencapai nisab"}</p>
      <p><strong>Zakat 2,5%:</strong> ${format(zakat)}</p>
    </div>`;
  });
});