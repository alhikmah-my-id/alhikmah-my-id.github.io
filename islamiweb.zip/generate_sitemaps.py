"""Alternatif generator sitemap (Python)."""
from pathlib import Path

BASE = "https://alhikmah.my.id"
PAGES = ["/", "/articles/", "/tools/", "/about/", "/contact/"]

xml = (
    '<?xml version="1.0" encoding="UTF-8"?>\n'
    '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
    + "\n".join(f"  <url><loc>{BASE}{p}</loc></url>" for p in PAGES)
    + "\n</urlset>\n"
)

Path("sitemap.xml").write_text(xml, encoding="utf-8")
print("sitemap.xml generated")